/// <reference types="@nuxt/ui" />
/// <reference types="@unocss/nuxt" />
/// <reference types="@pinia/nuxt" />
/// <reference types="@nuxtjs/i18n" />
/// <reference types="@nuxt/image" />
/// <reference types="@nuxt/eslint" />
/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxtjs/device" />
/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="pinia-plugin-persistedstate" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference types="../node_modules/.pnpm/@nuxt+vite-builder@4.2.1_@t_2af85ad69fc70e92e3d154c46329dada/node_modules/@nuxt/vite-builder/dist/index.mjs" />
/// <reference types="E:/work/code/kim/ceping/node_modules/.pnpm/@nuxt+nitro-server@4.2.1_db_bb40c2d4c03460244ab55c514da10d5a/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference path="image/providers.d.ts" />
/// <reference path="eslint-typegen.d.ts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
