import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};import { tmpdir } from 'node:os';
import { Server } from 'node:http';
import { resolve, dirname, join } from 'node:path';
import nodeCrypto from 'node:crypto';
import { parentPort, threadId } from 'node:worker_threads';
import { defineEventHandler, handleCacheHeaders, splitCookiesString, createEvent, fetchWithEvent, isEvent, eventHandler, setHeaders, sendRedirect, proxyRequest, getRequestHeader, setResponseHeaders, setResponseStatus, send, getRequestHeaders, setResponseHeader, appendResponseHeader, getRequestURL, getResponseHeader, getResponseStatus, createError, getCookie, setCookie, removeResponseHeader, getQuery as getQuery$1, readBody, getRouterParam, lazyEventHandler, useBase, createApp, createRouter as createRouter$1, toNodeListener, getResponseStatusText } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/h3@1.15.4/node_modules/h3/dist/index.mjs';
import { escapeHtml } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/@vue+shared@3.5.25/node_modules/@vue/shared/dist/shared.cjs.js';
import { createRenderer, getRequestDependencies, getPreloadLinks, getPrefetchLinks } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/vue-bundle-renderer@2.2.0/node_modules/vue-bundle-renderer/dist/runtime.mjs';
import { parseURL, withoutBase, joinURL, getQuery, withQuery, joinRelativeURL, parsePath, withLeadingSlash, withTrailingSlash, decodePath, withoutTrailingSlash } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/ufo@1.6.1/node_modules/ufo/dist/index.mjs';
import destr, { destr as destr$1 } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/destr@2.0.5/node_modules/destr/dist/index.mjs';
import process$1 from 'node:process';
import { renderToString } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/vue@3.5.25_typescript@5.9.3/node_modules/vue/server-renderer/index.mjs';
import { klona } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/klona@2.0.6/node_modules/klona/dist/index.mjs';
import defu, { defuFn, createDefu } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/defu@6.1.4/node_modules/defu/dist/defu.mjs';
import { snakeCase } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/scule@1.3.0/node_modules/scule/dist/index.mjs';
import { createHead as createHead$1, propsToString, renderSSRHead } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/unhead@2.0.19/node_modules/unhead/dist/server.mjs';
import { stringify, uneval } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/devalue@5.5.0/node_modules/devalue/index.js';
import { isVNode, toValue, isRef } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/vue@3.5.25_typescript@5.9.3/node_modules/vue/index.mjs';
import { createHooks } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/hookable@5.5.3/node_modules/hookable/dist/index.mjs';
import { createFetch, Headers as Headers$1 } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/ofetch@1.5.1/node_modules/ofetch/dist/node.mjs';
import { fetchNodeRequestHandler, callNodeRequestHandler } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/node-mock-http@1.0.4/node_modules/node-mock-http/dist/index.mjs';
import { createStorage, prefixStorage } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/unstorage@1.17.3_db0@0.3.4_ioredis@5.8.2/node_modules/unstorage/dist/index.mjs';
import unstorage_47drivers_47fs from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/unstorage@1.17.3_db0@0.3.4_ioredis@5.8.2/node_modules/unstorage/drivers/fs.mjs';
import { digest, hash as hash$1 } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/ohash@2.0.11/node_modules/ohash/dist/index.mjs';
import { toRouteMatcher, createRouter } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/radix3@1.1.2/node_modules/radix3/dist/index.mjs';
import { readFile } from 'node:fs/promises';
import consola, { consola as consola$1 } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/consola@3.4.2/node_modules/consola/dist/index.mjs';
import { ErrorParser } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/youch-core@0.3.3/node_modules/youch-core/build/index.js';
import { Youch } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/youch@4.1.0-beta.13/node_modules/youch/build/index.js';
import { SourceMapConsumer } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/source-map@0.7.6/node_modules/source-map/source-map.js';
import { createRouterMatcher } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/vue-router@4.6.3_vue@3.5.25_typescript@5.9.3_/node_modules/vue-router/vue-router.node.mjs';
import { AsyncLocalStorage } from 'node:async_hooks';
import { getContext } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/unctx@2.4.1/node_modules/unctx/dist/index.mjs';
import { captureRawStackTrace, parseRawStackTrace } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/errx@0.1.0/node_modules/errx/dist/index.js';
import { promises } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname as dirname$1, resolve as resolve$1, basename, isAbsolute } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/pathe@2.0.3/node_modules/pathe/dist/index.mjs';
import { walkResolver } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/unhead@2.0.19/node_modules/unhead/dist/utils.mjs';
import { getIcons } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/@iconify+utils@3.1.0/node_modules/@iconify/utils/lib/index.js';
import { collections } from 'file://E:/work/code/kim/ceping/.nuxt/nuxt-icon-server-bundle.mjs';
import { ipxFSStorage, ipxHttpStorage, createIPX, createIPXH3Handler } from 'file://E:/work/code/kim/ceping/node_modules/.pnpm/ipx@3.1.1_db0@0.3.4_ioredis@5.8.2/node_modules/ipx/dist/index.mjs';

const serverAssets = [{"baseName":"server","dir":"E:/work/code/kim/ceping/server/assets"}];

const assets$1 = createStorage();

for (const asset of serverAssets) {
  assets$1.mount(asset.baseName, unstorage_47drivers_47fs({ base: asset.dir, ignore: (asset?.ignore || []) }));
}

const storage$1 = createStorage({});

storage$1.mount('/assets', assets$1);

storage$1.mount('root', unstorage_47drivers_47fs({"driver":"fs","readOnly":true,"base":"E:/work/code/kim/ceping","watchOptions":{"ignored":[null]}}));
storage$1.mount('src', unstorage_47drivers_47fs({"driver":"fs","readOnly":true,"base":"E:/work/code/kim/ceping/server","watchOptions":{"ignored":[null]}}));
storage$1.mount('build', unstorage_47drivers_47fs({"driver":"fs","readOnly":false,"base":"E:/work/code/kim/ceping/.nuxt"}));
storage$1.mount('cache', unstorage_47drivers_47fs({"driver":"fs","readOnly":false,"base":"E:/work/code/kim/ceping/.nuxt/cache"}));
storage$1.mount('data', unstorage_47drivers_47fs({"driver":"fs","base":"E:/work/code/kim/ceping/.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage$1, base) : storage$1;
}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const defineAppConfig = (config) => config;

const appConfig0 = defineAppConfig({
  ui: {}
});

const inlineAppConfig = {
  "nuxt": {},
  "ui": {
    "colors": {
      "primary": "green",
      "secondary": "blue",
      "success": "green",
      "info": "blue",
      "warning": "yellow",
      "error": "red",
      "neutral": "slate"
    },
    "icons": {
      "arrowDown": "i-lucide-arrow-down",
      "arrowLeft": "i-lucide-arrow-left",
      "arrowRight": "i-lucide-arrow-right",
      "arrowUp": "i-lucide-arrow-up",
      "caution": "i-lucide-circle-alert",
      "check": "i-lucide-check",
      "chevronDoubleLeft": "i-lucide-chevrons-left",
      "chevronDoubleRight": "i-lucide-chevrons-right",
      "chevronDown": "i-lucide-chevron-down",
      "chevronLeft": "i-lucide-chevron-left",
      "chevronRight": "i-lucide-chevron-right",
      "chevronUp": "i-lucide-chevron-up",
      "close": "i-lucide-x",
      "copy": "i-lucide-copy",
      "copyCheck": "i-lucide-copy-check",
      "dark": "i-lucide-moon",
      "ellipsis": "i-lucide-ellipsis",
      "error": "i-lucide-circle-x",
      "external": "i-lucide-arrow-up-right",
      "eye": "i-lucide-eye",
      "eyeOff": "i-lucide-eye-off",
      "file": "i-lucide-file",
      "folder": "i-lucide-folder",
      "folderOpen": "i-lucide-folder-open",
      "hash": "i-lucide-hash",
      "info": "i-lucide-info",
      "light": "i-lucide-sun",
      "loading": "i-lucide-loader-circle",
      "menu": "i-lucide-menu",
      "minus": "i-lucide-minus",
      "panelClose": "i-lucide-panel-left-close",
      "panelOpen": "i-lucide-panel-left-open",
      "plus": "i-lucide-plus",
      "reload": "i-lucide-rotate-ccw",
      "search": "i-lucide-search",
      "stop": "i-lucide-square",
      "success": "i-lucide-circle-check",
      "system": "i-lucide-monitor",
      "tip": "i-lucide-lightbulb",
      "upload": "i-lucide-upload",
      "warning": "i-lucide-triangle-alert"
    },
    "tv": {
      "twMergeConfig": {}
    }
  },
  "icon": {
    "provider": "server",
    "class": "",
    "aliases": {},
    "iconifyApiEndpoint": "https://api.iconify.design",
    "localApiEndpoint": "/api/_nuxt_icon",
    "fallbackToApi": true,
    "cssSelectorPrefix": "i-",
    "cssWherePseudo": true,
    "cssLayer": "components",
    "mode": "css",
    "attrs": {
      "aria-hidden": true
    },
    "collections": [
      "academicons",
      "akar-icons",
      "ant-design",
      "arcticons",
      "basil",
      "bi",
      "bitcoin-icons",
      "bpmn",
      "brandico",
      "bx",
      "bxl",
      "bxs",
      "bytesize",
      "carbon",
      "catppuccin",
      "cbi",
      "charm",
      "ci",
      "cib",
      "cif",
      "cil",
      "circle-flags",
      "circum",
      "clarity",
      "codicon",
      "covid",
      "cryptocurrency",
      "cryptocurrency-color",
      "dashicons",
      "devicon",
      "devicon-plain",
      "ei",
      "el",
      "emojione",
      "emojione-monotone",
      "emojione-v1",
      "entypo",
      "entypo-social",
      "eos-icons",
      "ep",
      "et",
      "eva",
      "f7",
      "fa",
      "fa-brands",
      "fa-regular",
      "fa-solid",
      "fa6-brands",
      "fa6-regular",
      "fa6-solid",
      "fad",
      "fe",
      "feather",
      "file-icons",
      "flag",
      "flagpack",
      "flat-color-icons",
      "flat-ui",
      "flowbite",
      "fluent",
      "fluent-emoji",
      "fluent-emoji-flat",
      "fluent-emoji-high-contrast",
      "fluent-mdl2",
      "fontelico",
      "fontisto",
      "formkit",
      "foundation",
      "fxemoji",
      "gala",
      "game-icons",
      "geo",
      "gg",
      "gis",
      "gravity-ui",
      "gridicons",
      "grommet-icons",
      "guidance",
      "healthicons",
      "heroicons",
      "heroicons-outline",
      "heroicons-solid",
      "hugeicons",
      "humbleicons",
      "ic",
      "icomoon-free",
      "icon-park",
      "icon-park-outline",
      "icon-park-solid",
      "icon-park-twotone",
      "iconamoon",
      "iconoir",
      "icons8",
      "il",
      "ion",
      "iwwa",
      "jam",
      "la",
      "lets-icons",
      "line-md",
      "logos",
      "ls",
      "lucide",
      "lucide-lab",
      "mage",
      "majesticons",
      "maki",
      "map",
      "marketeq",
      "material-symbols",
      "material-symbols-light",
      "mdi",
      "mdi-light",
      "medical-icon",
      "memory",
      "meteocons",
      "mi",
      "mingcute",
      "mono-icons",
      "mynaui",
      "nimbus",
      "nonicons",
      "noto",
      "noto-v1",
      "octicon",
      "oi",
      "ooui",
      "openmoji",
      "oui",
      "pajamas",
      "pepicons",
      "pepicons-pencil",
      "pepicons-pop",
      "pepicons-print",
      "ph",
      "pixelarticons",
      "prime",
      "ps",
      "quill",
      "radix-icons",
      "raphael",
      "ri",
      "rivet-icons",
      "si-glyph",
      "simple-icons",
      "simple-line-icons",
      "skill-icons",
      "solar",
      "streamline",
      "streamline-emojis",
      "subway",
      "svg-spinners",
      "system-uicons",
      "tabler",
      "tdesign",
      "teenyicons",
      "token",
      "token-branded",
      "topcoat",
      "twemoji",
      "typcn",
      "uil",
      "uim",
      "uis",
      "uit",
      "uiw",
      "unjs",
      "vaadin",
      "vs",
      "vscode-icons",
      "websymbol",
      "weui",
      "whh",
      "wi",
      "wpf",
      "zmdi",
      "zondicons"
    ],
    "fetchTimeout": 1500
  }
};

const appConfig = defuFn(appConfig0, inlineAppConfig);

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildId": "dev",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      }
    }
  },
  "public": {
    "strapiApiUrl": "http://18.209.4.212:55532/api",
    "strapiUrl": "http://18.209.4.212:55532/",
    "apiBaseUrl": "https://api.personalitytest101.com/api",
    "device": {
      "defaultUserAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.39 Safari/537.36"
    },
    "i18n": {
      "baseUrl": "https://example.com",
      "defaultLocale": "en",
      "rootRedirect": "",
      "redirectStatusCode": 302,
      "skipSettingLocaleOnNavigate": false,
      "locales": [
        {
          "code": "en",
          "language": "en-US",
          "name": "English",
          "mobileName": "EN"
        }
      ],
      "detectBrowserLanguage": false,
      "experimental": {
        "localeDetector": "",
        "typedPages": true,
        "typedOptionsAndMessages": false,
        "alternateLinkCanonicalQueries": true,
        "devCache": false,
        "cacheLifetime": "",
        "stripMessagesPayload": false,
        "preload": false,
        "strictSeo": false,
        "nitroContextDetection": true,
        "httpCacheDuration": 10
      },
      "domainLocales": {
        "en": {
          "domain": ""
        }
      }
    }
  },
  "icon": {
    "serverKnownCssClasses": []
  },
  "ipx": {
    "baseURL": "/_ipx",
    "alias": {},
    "fs": {
      "dir": [
        "E:/work/code/kim/ceping/public"
      ]
    },
    "http": {
      "domains": []
    }
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
const _sharedAppConfig = _deepFreeze(klona(appConfig));
function useAppConfig(event) {
  {
    return _sharedAppConfig;
  }
}
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

function isJsonRequest(event) {
  if (hasReqHeader(event, "accept", "text/html")) {
    return false;
  }
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}

const iframeStorageBridge = (nonce) => (
  /* js */
  `
(function() {
  const memoryStore = {};

  const NONCE = ${JSON.stringify(nonce)}
  
  const mockStorage = {
    getItem: function(key) {
      return memoryStore[key] !== undefined ? memoryStore[key] : null;
    },
    setItem: function(key, value) {
      memoryStore[key] = String(value);
      window.parent.postMessage({
        type: 'storage-set',
        key: key,
        value: String(value),
        nonce: NONCE
      }, '*');
    },
    removeItem: function(key) {
      delete memoryStore[key];
      window.parent.postMessage({
        type: 'storage-remove',
        key: key,
        nonce: NONCE
      }, '*');
    },
    clear: function() {
      for (const key in memoryStore) {
        delete memoryStore[key];
      }
      window.parent.postMessage({
        type: 'storage-clear',
        nonce: NONCE
      }, '*');
    },
    key: function(index) {
      const keys = Object.keys(memoryStore);
      return keys[index] !== undefined ? keys[index] : null;
    },
    get length() {
      return Object.keys(memoryStore).length;
    }
  };
  
  try {
    Object.defineProperty(window, 'localStorage', {
      value: mockStorage,
      writable: false,
      configurable: true
    });
  } catch (e) {
    window.localStorage = mockStorage;
  }
  
  window.addEventListener('message', function(event) {
    if (event.data.type === 'storage-sync-data' && event.data.nonce === NONCE) {
      const data = event.data.data;
      for (const key in data) {
        if (Object.prototype.hasOwnProperty.call(data, key)) {
          memoryStore[key] = data[key];
        }
      }
      if (typeof window.initTheme === 'function') {
        window.initTheme();
      }
      window.dispatchEvent(new Event('storage-ready'));
    }
  });
  
  window.parent.postMessage({ 
    type: 'storage-sync-request',
    nonce: NONCE
  }, '*');
})();
`
);
const parentStorageBridge = (nonce) => (
  /* js */
  `
(function() {
  const host = document.querySelector('nuxt-error-overlay');
  if (!host) return;
  
  // Wait for shadow root to be attached
  const checkShadow = setInterval(function() {
    if (host.shadowRoot) {
      clearInterval(checkShadow);
      const iframe = host.shadowRoot.getElementById('frame');
      if (!iframe) return;

      const NONCE = ${JSON.stringify(nonce)}
      
      window.addEventListener('message', function(event) {
        if (!event.data || event.data.nonce !== NONCE) return;
        
        const data = event.data;
        
        if (data.type === 'storage-set') {
          localStorage.setItem(data.key, data.value);
        } else if (data.type === 'storage-remove') {
          localStorage.removeItem(data.key);
        } else if (data.type === 'storage-clear') {
          localStorage.clear();
        } else if (data.type === 'storage-sync-request') {
          const allData = {};
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            allData[key] = localStorage.getItem(key);
          }
          iframe.contentWindow.postMessage({
            type: 'storage-sync-data',
            data: allData,
            nonce: NONCE
          }, '*');
        }
      });
    }
  }, 10);
})();
`
);
const errorCSS = (
  /* css */
  `
:host {
  --preview-width: 240px;
  --preview-height: 180px;
  --base-width: 1200px;
  --base-height: 900px;
  --z-base: 999999998;
  all: initial;
  display: contents;
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
#frame {
  position: fixed;
  left: 0;
  top: 0;
  width: 100vw;
  height: 100vh;
  border: none;
  z-index: var(--z-base);
}
#frame[inert] {
  right: 5px;
  bottom: 5px;
  left: auto;
  top: auto;
  width: var(--base-width);
  height: var(--base-height);
  transform: scale(calc(240 / 1200));
  transform-origin: bottom right;
  overflow: hidden;
  border-radius: calc(1200 * 8px / 240);
}
#preview {
  position: fixed;
  right: 5px;
  bottom: 5px;
  width: var(--preview-width);
  height: var(--preview-height);
  overflow: hidden;
  border-radius: 8px;
  pointer-events: none;
  z-index: var(--z-base);
  background: white;
  display: none;
}
#frame:not([inert]) + #preview {
  display: block;
}
#toggle {
  position: fixed;
  right: 5px;
  bottom: 5px;
  width: var(--preview-width);
  height: var(--preview-height);
  background: none;
  border: 3px solid #00DC82;
  border-radius: 8px;
  cursor: pointer;
  opacity: 0.8;
  transition: opacity 0.2s, box-shadow 0.2s;
  z-index: calc(var(--z-base) + 1);
}
#toggle:hover,
#toggle:focus {
  opacity: 1;
  box-shadow: 0 0 20px rgba(0, 220, 130, 0.6);
}
#toggle:focus-visible {
  outline: 3px solid #00DC82;
  outline-offset: 3px;
  box-shadow: 0 0 24px rgba(0, 220, 130, 0.8);
}
@media (prefers-reduced-motion: reduce) {
  #toggle {
    transition: none;
  }
}
`
);
function webComponentScript(base64HTML, startMinimized) {
  return (
    /* js */
    `
  (function() {
    try {
      const host = document.querySelector('nuxt-error-overlay');
      if (!host) return;
      
      const shadow = host.attachShadow({ mode: 'open' });
      
      // Create elements
      const style = document.createElement('style');
      style.textContent = ${JSON.stringify(errorCSS)};
      
      const iframe = document.createElement('iframe');
      iframe.id = 'frame';
      iframe.src = 'data:text/html;base64,${base64HTML}';
      iframe.title = 'Detailed error stack trace';
      iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin');
      
      const preview = document.createElement('div');
      preview.id = 'preview';
      
      const button = document.createElement('button');
      button.id = 'toggle';
      button.setAttribute('aria-expanded', 'true');
      button.setAttribute('type', 'button');
      button.innerHTML = '<span class="sr-only">Toggle detailed error view</span>';
      
      const liveRegion = document.createElement('div');
      liveRegion.setAttribute('role', 'status');
      liveRegion.setAttribute('aria-live', 'polite');
      liveRegion.className = 'sr-only';
      
      // Update preview snapshot
      function updatePreview() {
        try {
          let previewIframe = preview.querySelector('iframe');
          if (!previewIframe) {
            previewIframe = document.createElement('iframe');
            previewIframe.style.cssText = 'width: 1200px; height: 900px; transform: scale(0.2); transform-origin: top left; border: none;';
            previewIframe.setAttribute('sandbox', 'allow-scripts allow-same-origin');
            preview.appendChild(previewIframe);
          }
          
          const doctype = document.doctype ? '<!DOCTYPE ' + document.doctype.name + '>' : '';
          const cleanedHTML = document.documentElement.outerHTML
            .replace(/<nuxt-error-overlay[^>]*>.*?<\\/nuxt-error-overlay>/gs, '')
            .replace(/<script[^>]*>.*?<\\/script>/gs, '');
          
          const iframeDoc = previewIframe.contentDocument || previewIframe.contentWindow.document;
          iframeDoc.open();
          iframeDoc.write(doctype + cleanedHTML);
          iframeDoc.close();
        } catch (error) {
          console.error('Failed to update preview:', error);
        }
      }
      
      function toggleView() {
        const isMinimized = iframe.hasAttribute('inert');
        
        if (isMinimized) {
          updatePreview();
          iframe.removeAttribute('inert');
          button.setAttribute('aria-expanded', 'true');
          liveRegion.textContent = 'Showing detailed error view';
          setTimeout(function() {
            try { iframe.contentWindow.focus(); } catch {}
          }, 100);
        } else {
          iframe.setAttribute('inert', '');
          button.setAttribute('aria-expanded', 'false');
          liveRegion.textContent = 'Showing error page';
          button.focus();
        }
      }
      
      button.onclick = toggleView;
      
      document.addEventListener('keydown', function(e) {
        if ((e.key === 'Escape' || e.key === 'Esc') && !iframe.hasAttribute('inert')) {
          toggleView();
        }
      });
      
      // Append to shadow DOM
      shadow.appendChild(style);
      shadow.appendChild(liveRegion);
      shadow.appendChild(iframe);
      shadow.appendChild(preview);
      shadow.appendChild(button);
      
      if (${startMinimized}) {
        iframe.setAttribute('inert', '');
        button.setAttribute('aria-expanded', 'false');
      }
      
      // Initialize preview
      setTimeout(updatePreview, 100);
      
    } catch (error) {
      console.error('Failed to initialize Nuxt error overlay:', error);
    }
  })();
  `
  );
}
function generateErrorOverlayHTML(html, options) {
  const nonce = Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, "0")).join("");
  const errorPage = html.replace("<head>", `<head><script>${iframeStorageBridge(nonce)}<\/script>`);
  const base64HTML = Buffer.from(errorPage, "utf8").toString("base64");
  return `
    <script>${parentStorageBridge(nonce)}<\/script>
    <nuxt-error-overlay></nuxt-error-overlay>
    <script>${webComponentScript(base64HTML, options?.startMinimized ?? false)}<\/script>
  `;
}

const errorHandler$0 = (async function errorhandler(error, event, { defaultHandler }) {
  if (event.handled || isJsonRequest(event)) {
    return;
  }
  const defaultRes = await defaultHandler(error, event, { json: true });
  const statusCode = error.statusCode || 500;
  if (statusCode === 404 && defaultRes.status === 302) {
    setResponseHeaders(event, defaultRes.headers);
    setResponseStatus(event, defaultRes.status, defaultRes.statusText);
    return send(event, JSON.stringify(defaultRes.body, null, 2));
  }
  if (typeof defaultRes.body !== "string" && Array.isArray(defaultRes.body.stack)) {
    defaultRes.body.stack = defaultRes.body.stack.join("\n");
  }
  const errorObject = defaultRes.body;
  const url = new URL(errorObject.url);
  errorObject.url = withoutBase(url.pathname, useRuntimeConfig(event).app.baseURL) + url.search + url.hash;
  errorObject.message ||= "Server Error";
  errorObject.data ||= error.data;
  errorObject.statusMessage ||= error.statusMessage;
  delete defaultRes.headers["content-type"];
  delete defaultRes.headers["content-security-policy"];
  setResponseHeaders(event, defaultRes.headers);
  const reqHeaders = getRequestHeaders(event);
  const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"];
  const res = isRenderingError ? null : await useNitroApp().localFetch(
    withQuery(joinURL(useRuntimeConfig(event).app.baseURL, "/__nuxt_error"), errorObject),
    {
      headers: { ...reqHeaders, "x-nuxt-error": "true" },
      redirect: "manual"
    }
  ).catch(() => null);
  if (event.handled) {
    return;
  }
  if (!res) {
    const { template } = await Promise.resolve().then(function () { return error500; });
    {
      errorObject.description = errorObject.message;
    }
    setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
    return send(event, template(errorObject));
  }
  const html = await res.text();
  for (const [header, value] of res.headers.entries()) {
    if (header === "set-cookie") {
      appendResponseHeader(event, header, value);
      continue;
    }
    setResponseHeader(event, header, value);
  }
  setResponseStatus(event, res.status && res.status !== 200 ? res.status : defaultRes.status, res.statusText || defaultRes.statusText);
  {
    const prettyResponse = await defaultHandler(error, event, { json: false });
    return send(event, html.replace("</body>", `${generateErrorOverlayHTML(prettyResponse.body, { startMinimized: 300 <= statusCode && statusCode < 500 })}</body>`));
  }
});

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$1 = defineNitroErrorHandler(
  async function defaultNitroErrorHandler(error, event) {
    const res = await defaultHandler(error, event);
    if (!event.node?.res.headersSent) {
      setResponseHeaders(event, res.headers);
    }
    setResponseStatus(event, res.status, res.statusText);
    return send(
      event,
      typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2)
    );
  }
);
async function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  await loadStackTrace(error).catch(consola.error);
  const youch = new Youch();
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    const ansiError = await (await youch.toANSI(error)).replaceAll(process.cwd(), ".");
    consola.error(
      `[request error] ${tags} [${event.method}] ${url}

`,
      ansiError
    );
  }
  const useJSON = opts?.json || !getRequestHeader(event, "accept")?.includes("text/html");
  const headers = {
    "content-type": useJSON ? "application/json" : "text/html",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self';"
  };
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = useJSON ? {
    error: true,
    url,
    statusCode,
    statusMessage,
    message: error.message,
    data: error.data,
    stack: error.stack?.split("\n").map((line) => line.trim())
  } : await youch.toHTML(error, {
    request: {
      url: url.href,
      method: event.method,
      headers: getRequestHeaders(event)
    }
  });
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}
async function loadStackTrace(error) {
  if (!(error instanceof Error)) {
    return;
  }
  const parsed = await new ErrorParser().defineSourceLoader(sourceLoader).parse(error);
  const stack = error.message + "\n" + parsed.frames.map((frame) => fmtFrame(frame)).join("\n");
  Object.defineProperty(error, "stack", { value: stack });
  if (error.cause) {
    await loadStackTrace(error.cause).catch(consola.error);
  }
}
async function sourceLoader(frame) {
  if (!frame.fileName || frame.fileType !== "fs" || frame.type === "native") {
    return;
  }
  if (frame.type === "app") {
    const rawSourceMap = await readFile(`${frame.fileName}.map`, "utf8").catch(() => {
    });
    if (rawSourceMap) {
      const consumer = await new SourceMapConsumer(rawSourceMap);
      const originalPosition = consumer.originalPositionFor({ line: frame.lineNumber, column: frame.columnNumber });
      if (originalPosition.source && originalPosition.line) {
        frame.fileName = resolve(dirname(frame.fileName), originalPosition.source);
        frame.lineNumber = originalPosition.line;
        frame.columnNumber = originalPosition.column || 0;
      }
    }
  }
  const contents = await readFile(frame.fileName, "utf8").catch(() => {
  });
  return contents ? { contents } : void 0;
}
function fmtFrame(frame) {
  if (frame.type === "native") {
    return frame.raw;
  }
  const src = `${frame.fileName || ""}:${frame.lineNumber}:${frame.columnNumber})`;
  return frame.functionName ? `at ${frame.functionName} (${src}` : `at ${src}`;
}

const errorHandlers = [errorHandler$0, errorHandler$1];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

const script$1 = `
if (!window.__NUXT_DEVTOOLS_TIME_METRIC__) {
  Object.defineProperty(window, '__NUXT_DEVTOOLS_TIME_METRIC__', {
    value: {},
    enumerable: false,
    configurable: true,
  })
}
window.__NUXT_DEVTOOLS_TIME_METRIC__.appInit = Date.now()
`;

const _Hmq137YzPB4HwUUoriJKhq6Q8oE8KxmAFh5CsXLAkCU = (function(nitro) {
  nitro.hooks.hook("render:html", (htmlContext) => {
    htmlContext.head.push(`<script>${script$1}<\/script>`);
  });
});

/*!
  * shared v11.2.2
  * (c) 2025 kazuya kawaguchi
  * Released under the MIT License.
  */
const _create = Object.create;
const create = (obj = null) => _create(obj);
/* eslint-enable */
/**
 * Useful Utilities By Evan you
 * Modified by kazuya kawaguchi
 * MIT License
 * https://github.com/vuejs/vue-next/blob/master/packages/shared/src/index.ts
 * https://github.com/vuejs/vue-next/blob/master/packages/shared/src/codeframe.ts
 */
const isArray = Array.isArray;
const isFunction = (val) => typeof val === 'function';
const isString = (val) => typeof val === 'string';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const isObject = (val) => val !== null && typeof val === 'object';
const objectToString = Object.prototype.toString;
const toTypeString = (value) => objectToString.call(value);

const isNotObjectOrIsArray = (val) => !isObject(val) || isArray(val);
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function deepCopy(src, des) {
    // src and des should both be objects, and none of them can be a array
    if (isNotObjectOrIsArray(src) || isNotObjectOrIsArray(des)) {
        throw new Error('Invalid value');
    }
    const stack = [{ src, des }];
    while (stack.length) {
        const { src, des } = stack.pop();
        // using `Object.keys` which skips prototype properties
        Object.keys(src).forEach(key => {
            if (key === '__proto__') {
                return;
            }
            // if src[key] is an object/array, set des[key]
            // to empty object/array to prevent setting by reference
            if (isObject(src[key]) && !isObject(des[key])) {
                des[key] = Array.isArray(src[key]) ? [] : create();
            }
            if (isNotObjectOrIsArray(des[key]) || isNotObjectOrIsArray(src[key])) {
                // replace with src[key] when:
                // src[key] or des[key] is not an object, or
                // src[key] or des[key] is an array
                des[key] = src[key];
            }
            else {
                // src[key] and des[key] are both objects, merge them
                stack.push({ src: src[key], des: des[key] });
            }
        });
    }
}

const __nuxtMock = { runWithContext: async (fn) => await fn() };
const merger = createDefu((obj, key, value) => {
  if (key === "messages" || key === "datetimeFormats" || key === "numberFormats") {
    obj[key] ??= create(null);
    deepCopy(value, obj[key]);
    return true;
  }
});
async function loadVueI18nOptions(vueI18nConfigs) {
  const nuxtApp = __nuxtMock;
  let vueI18nOptions = { messages: create(null) };
  for (const configFile of vueI18nConfigs) {
    const resolver = await configFile().then((x) => x.default);
    const resolved = isFunction(resolver) ? await nuxtApp.runWithContext(() => resolver()) : resolver;
    vueI18nOptions = merger(create(null), resolved, vueI18nOptions);
  }
  vueI18nOptions.fallbackLocale ??= false;
  return vueI18nOptions;
}
const isModule = (val) => toTypeString(val) === "[object Module]";
const isResolvedModule = (val) => isModule(val) || true;
async function getLocaleMessages(locale, loader) {
  const nuxtApp = __nuxtMock;
  try {
    const getter = await nuxtApp.runWithContext(loader.load).then((x) => isResolvedModule(x) ? x.default : x);
    return isFunction(getter) ? await nuxtApp.runWithContext(() => getter(locale)) : getter;
  } catch (e) {
    throw new Error(`Failed loading locale (${locale}): ` + e.message);
  }
}
async function getLocaleMessagesMerged(locale, loaders = []) {
  const nuxtApp = __nuxtMock;
  const messages = await Promise.all(
    loaders.map((loader) => nuxtApp.runWithContext(() => getLocaleMessages(locale, loader)))
  );
  const merged = {};
  for (const message of messages) {
    deepCopy(message, merged);
  }
  return merged;
}

// @ts-nocheck
const localeCodes =  [
  "en"
];
const localeLoaders = {
  en: [
    {
      key: "locale_en_46ts_3d225fc9",
      load: () => Promise.resolve().then(function () { return en$1; }),
      cache: true
    }
  ]
};
const vueI18nConfigs = [
  () => Promise.resolve().then(function () { return i18n_config$1; })
];
const normalizedLocales = [
  {
    code: "en",
    language: "en-US",
    name: "English",
    mobileName: "EN"
  }
];

const setupVueI18nOptions = async (defaultLocale) => {
  const options = await loadVueI18nOptions(vueI18nConfigs);
  options.locale = defaultLocale || options.locale || "en-US";
  options.defaultLocale = defaultLocale;
  options.fallbackLocale ??= false;
  options.messages ??= {};
  for (const locale of localeCodes) {
    options.messages[locale] ??= {};
  }
  return options;
};

function defineNitroPlugin(def) {
  return def;
}

function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig();
  return eventHandler(async (event) => {
    const nitroApp = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}

const scheduledTasks = false;

const tasks = {
  
};

const __runningTasks__ = {};
async function runTask(name, {
  payload = {},
  context = {}
} = {}) {
  if (__runningTasks__[name]) {
    return __runningTasks__[name];
  }
  if (!(name in tasks)) {
    throw createError({
      message: `Task \`${name}\` is not available!`,
      statusCode: 404
    });
  }
  if (!tasks[name].resolve) {
    throw createError({
      message: `Task \`${name}\` is not implemented!`,
      statusCode: 501
    });
  }
  const handler = await tasks[name].resolve();
  const taskEvent = { name, payload, context };
  __runningTasks__[name] = handler.run(taskEvent);
  try {
    const res = await __runningTasks__[name];
    return res;
  } finally {
    delete __runningTasks__[name];
  }
}

function buildAssetsDir() {
  return useRuntimeConfig().app.buildAssetsDir;
}
function buildAssetsURL(...path) {
  return joinRelativeURL(publicAssetsURL(), buildAssetsDir(), ...path);
}
function publicAssetsURL(...path) {
  const app = useRuntimeConfig().app;
  const publicBase = app.cdnURL || app.baseURL;
  return path.length ? joinRelativeURL(publicBase, ...path) : publicBase;
}

function parseAcceptLanguage(value) {
  return value.split(",").map((tag) => tag.split(";")[0]).filter(
    (tag) => !(tag === "*" || tag === "")
  );
}
function createPathIndexLanguageParser(index = 0) {
  return (path) => {
    const rawPath = typeof path === "string" ? path : path.pathname;
    const normalizedPath = rawPath.split("?")[0];
    const parts = normalizedPath.split("/");
    if (parts[0] === "") {
      parts.shift();
    }
    return parts.length > index ? parts[index] || "" : "";
  };
}

function useRuntimeI18n(nuxtApp, event) {
  {
    return useRuntimeConfig(event).public.i18n;
  }
}
function useI18nDetection(nuxtApp) {
  const detectBrowserLanguage = useRuntimeI18n().detectBrowserLanguage;
  const detect = detectBrowserLanguage || {};
  return {
    ...detect,
    enabled: !!detectBrowserLanguage,
    cookieKey: detect.cookieKey || "i18n_redirected"
  };
}
function resolveRootRedirect(config) {
  if (!config) {
    return void 0;
  }
  return {
    path: "/" + (isString(config) ? config : config.path).replace(/^\//, ""),
    code: !isString(config) && config.statusCode || 302
  };
}
function toArray(value) {
  return Array.isArray(value) ? value : [value];
}

function createLocaleConfigs(fallbackLocale) {
  const localeConfigs = {};
  for (const locale of localeCodes) {
    const fallbacks = getFallbackLocaleCodes(fallbackLocale, [locale]);
    const cacheable = isLocaleWithFallbacksCacheable(locale, fallbacks);
    localeConfigs[locale] = { fallbacks, cacheable };
  }
  return localeConfigs;
}
function getFallbackLocaleCodes(fallback, locales) {
  if (fallback === false) {
    return [];
  }
  if (isArray(fallback)) {
    return fallback;
  }
  let fallbackLocales = [];
  if (isString(fallback)) {
    if (locales.every((locale) => locale !== fallback)) {
      fallbackLocales.push(fallback);
    }
    return fallbackLocales;
  }
  const targets = [...locales, "default"];
  for (const locale of targets) {
    if (locale in fallback == false) {
      continue;
    }
    fallbackLocales = [...fallbackLocales, ...fallback[locale].filter(Boolean)];
  }
  return fallbackLocales;
}
function isLocaleCacheable(locale) {
  return localeLoaders[locale] != null && localeLoaders[locale].every((loader) => loader.cache !== false);
}
function isLocaleWithFallbacksCacheable(locale, fallbackLocales) {
  return isLocaleCacheable(locale) && fallbackLocales.every((fallbackLocale) => isLocaleCacheable(fallbackLocale));
}
function getDefaultLocaleForDomain(host) {
  return normalizedLocales.find((l) => !!l.defaultForDomains?.includes(host))?.code;
}
const isSupportedLocale = (locale) => localeCodes.includes(locale || "");

function useI18nContext(event) {
  if (event.context.nuxtI18n == null) {
    throw new Error("Nuxt I18n server context has not been set up yet.");
  }
  return event.context.nuxtI18n;
}
function tryUseI18nContext(event) {
  return event.context.nuxtI18n;
}
const getHost = (event) => getRequestURL(event, { xForwardedHost: true }).host;
async function initializeI18nContext(event) {
  const runtimeI18n = useRuntimeI18n(void 0, event);
  const defaultLocale = runtimeI18n.defaultLocale || "";
  const options = await setupVueI18nOptions(getDefaultLocaleForDomain(getHost(event)) || defaultLocale);
  const localeConfigs = createLocaleConfigs(options.fallbackLocale);
  const ctx = createI18nContext();
  ctx.vueI18nOptions = options;
  ctx.localeConfigs = localeConfigs;
  event.context.nuxtI18n = ctx;
  return ctx;
}
function createI18nContext() {
  return {
    messages: {},
    slp: {},
    localeConfigs: {},
    trackMap: {},
    vueI18nOptions: void 0,
    trackKey(key, locale) {
      this.trackMap[locale] ??= /* @__PURE__ */ new Set();
      this.trackMap[locale].add(key);
    }
  };
}

function matchBrowserLocale(locales, browserLocales) {
  const matchedLocales = [];
  for (const [index, browserCode] of browserLocales.entries()) {
    const matchedLocale = locales.find((l) => l.language?.toLowerCase() === browserCode.toLowerCase());
    if (matchedLocale) {
      matchedLocales.push({ code: matchedLocale.code, score: 1 - index / browserLocales.length });
      break;
    }
  }
  for (const [index, browserCode] of browserLocales.entries()) {
    const languageCode = browserCode.split("-")[0].toLowerCase();
    const matchedLocale = locales.find((l) => l.language?.split("-")[0].toLowerCase() === languageCode);
    if (matchedLocale) {
      matchedLocales.push({ code: matchedLocale.code, score: 0.999 - index / browserLocales.length });
      break;
    }
  }
  return matchedLocales;
}
function compareBrowserLocale(a, b) {
  if (a.score === b.score) {
    return b.code.length - a.code.length;
  }
  return b.score - a.score;
}
function findBrowserLocale(locales, browserLocales) {
  const matchedLocales = matchBrowserLocale(
    locales.map((l) => ({ code: l.code, language: l.language || l.code })),
    browserLocales
  );
  return matchedLocales.sort(compareBrowserLocale).at(0)?.code ?? "";
}

const appHead = {"meta":[{"charset":"utf-8"},{"name":"viewport","content":"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"}],"link":[],"style":[],"script":[],"noscript":[]};

const appRootTag = "div";

const appRootAttrs = {"id":"__nuxt","class":"isolate"};

const appTeleportTag = "div";

const appTeleportAttrs = {"id":"teleports"};

const appSpaLoaderTag = "div";

const appSpaLoaderAttrs = {"id":"__nuxt-loader"};

const appId = "nuxt-app";

const separator = "___";
const pathLanguageParser = createPathIndexLanguageParser(0);
const getLocaleFromRoutePath = (path) => pathLanguageParser(path);
const getLocaleFromRouteName = (name) => name.split(separator).at(1) ?? "";
function normalizeInput(input) {
  return typeof input !== "object" ? String(input) : String(input?.name || input?.path || "");
}
function getLocaleFromRoute(route) {
  const input = normalizeInput(route);
  return input[0] === "/" ? getLocaleFromRoutePath(input) : getLocaleFromRouteName(input);
}

function matchDomainLocale(locales, host, pathLocale) {
  const normalizeDomain = (domain = "") => domain.replace(/https?:\/\//, "");
  const matches = locales.filter(
    (locale) => normalizeDomain(locale.domain) === host || toArray(locale.domains).includes(host)
  );
  if (matches.length <= 1) {
    return matches[0]?.code;
  }
  return (
    // match by current path locale
    matches.find((l) => l.code === pathLocale)?.code || matches.find((l) => l.defaultForDomains?.includes(host) ?? l.domainDefault)?.code
  );
}

const getCookieLocale = (event, cookieName) => (getCookie(event, cookieName)) || void 0;
const getRouteLocale = (event, route) => getLocaleFromRoute(route);
const getHeaderLocale = (event) => findBrowserLocale(normalizedLocales, parseAcceptLanguage(getRequestHeader(event, "accept-language") || ""));
const getHostLocale = (event, path, domainLocales) => {
  const host = getRequestURL(event, { xForwardedHost: true }).host;
  const locales = normalizedLocales.map((l) => ({
    ...l,
    domain: domainLocales[l.code]?.domain ?? l.domain
  }));
  return matchDomainLocale(locales, host, getLocaleFromRoutePath(path));
};
const useDetectors = (event, config, nuxtApp) => {
  if (!event) {
    throw new Error("H3Event is required for server-side locale detection");
  }
  const runtimeI18n = useRuntimeI18n();
  return {
    cookie: () => getCookieLocale(event, config.cookieKey),
    header: () => getHeaderLocale(event) ,
    navigator: () => void 0,
    host: (path) => getHostLocale(event, path, runtimeI18n.domainLocales),
    route: (path) => getRouteLocale(event, path)
  };
};

// Generated by @nuxtjs/i18n
const pathToI18nConfig = {
  "/pricing": {
    "en": "/pricing"
  },
  "/faq": {
    "en": "/faq"
  },
  "/test/step": {
    "en": "/test/step"
  },
  "/blog": {
    "en": "/blog"
  },
  "/test": {
    "en": "/test"
  },
  "/test/start": {
    "en": "/test/start"
  },
  "/about": {
    "en": "/about"
  },
  "/index": {
    "en": "/index"
  },
  "/route-guide": {
    "en": "/route-guide"
  },
  "/test/finish": {
    "en": "/test/finish"
  },
  "/test/report": {
    "en": "/test/report"
  },
  "/test/result": {
    "en": "/test/result"
  },
  "/tests": {
    "en": "/tests"
  },
  "/auth/sign-in": {
    "en": "/auth/sign-in"
  },
  "/ebooks": {
    "en": "/ebooks"
  },
  "/contact": {
    "en": "/contact"
  },
  "/courses": {
    "en": "/courses"
  },
  "/ebooks/detail": {
    "en": "/ebooks/detail"
  },
  "/legal/privacy": {
    "en": "/legal/privacy"
  },
  "/orders/create": {
    "en": "/orders/create"
  },
  "/profile": {
    "en": "/profile"
  },
  "/-mentors": {
    "en": "/-mentors"
  },
  "/profile/detail": {
    "en": "/profile/detail"
  },
  "/test/analyzing": {
    "en": "/test/analyzing"
  },
  "/account/settings": {
    "en": "/account/settings"
  },
  "/user-course/test": {
    "en": "/user-course/test"
  },
  "/blog/dateil/:slug()": {
    "en": "/blog/dateil/:slug()"
  },
  "/legal/terms-of-use": {
    "en": "/legal/terms-of-use"
  },
  "/user-course/lesson": {
    "en": "/user-course/lesson"
  },
  "/legal/refund-policy": {
    "en": "/legal/refund-policy"
  },
  "/blog/category/:slug()": {
    "en": "/blog/category/:slug()"
  },
  "/user-course/chapters": {
    "en": "/user-course/chapters"
  },
  "/orders/purchase-complete": {
    "en": "/orders/purchase-complete"
  },
  "/user-course/lesson-guide": {
    "en": "/user-course/lesson-guide"
  },
  "/user-course/test-complete": {
    "en": "/user-course/test-complete"
  },
  "/orders/cancel-subscription": {
    "en": "/orders/cancel-subscription"
  },
  "/user-course/lesson-complete": {
    "en": "/user-course/lesson-complete"
  },
  "/user-course/chapter-complete": {
    "en": "/user-course/chapter-complete"
  }
};
const i18nPathToPath = {
  "/pricing": "/pricing",
  "/faq": "/faq",
  "/test/step": "/test/step",
  "/blog": "/blog",
  "/test": "/test",
  "/test/start": "/test/start",
  "/about": "/about",
  "/index": "/index",
  "/route-guide": "/route-guide",
  "/test/finish": "/test/finish",
  "/test/report": "/test/report",
  "/test/result": "/test/result",
  "/tests": "/tests",
  "/auth/sign-in": "/auth/sign-in",
  "/ebooks": "/ebooks",
  "/contact": "/contact",
  "/courses": "/courses",
  "/ebooks/detail": "/ebooks/detail",
  "/legal/privacy": "/legal/privacy",
  "/orders/create": "/orders/create",
  "/profile": "/profile",
  "/-mentors": "/-mentors",
  "/profile/detail": "/profile/detail",
  "/test/analyzing": "/test/analyzing",
  "/account/settings": "/account/settings",
  "/user-course/test": "/user-course/test",
  "/blog/dateil/:slug()": "/blog/dateil/:slug()",
  "/legal/terms-of-use": "/legal/terms-of-use",
  "/user-course/lesson": "/user-course/lesson",
  "/legal/refund-policy": "/legal/refund-policy",
  "/blog/category/:slug()": "/blog/category/:slug()",
  "/user-course/chapters": "/user-course/chapters",
  "/orders/purchase-complete": "/orders/purchase-complete",
  "/user-course/lesson-guide": "/user-course/lesson-guide",
  "/user-course/test-complete": "/user-course/test-complete",
  "/orders/cancel-subscription": "/orders/cancel-subscription",
  "/user-course/lesson-complete": "/user-course/lesson-complete",
  "/user-course/chapter-complete": "/user-course/chapter-complete"
};

const matcher = createRouterMatcher([], {});
for (const path of Object.keys(i18nPathToPath)) {
  matcher.addRoute({ path, component: () => "", meta: {} });
}
const getI18nPathToI18nPath = (path, locale) => {
  if (!path || !locale) {
    return;
  }
  const plainPath = i18nPathToPath[path];
  const i18nConfig = pathToI18nConfig[plainPath];
  if (i18nConfig && i18nConfig[locale]) {
    return i18nConfig[locale] === true ? plainPath : i18nConfig[locale];
  }
};
function isExistingNuxtRoute(path) {
  if (path === "") {
    return;
  }
  if (path.endsWith("/__nuxt_error")) {
    return;
  }
  const resolvedMatch = matcher.resolve({ path }, { path: "/", name: "", matched: [], params: {}, meta: {} });
  return resolvedMatch.matched.length > 0 ? resolvedMatch : void 0;
}
function matchLocalized(path, locale, defaultLocale) {
  if (path === "") {
    return;
  }
  const parsed = parsePath(path);
  const resolvedMatch = matcher.resolve(
    { path: parsed.pathname || "/" },
    { path: "/", name: "", matched: [], params: {}, meta: {} }
  );
  if (resolvedMatch.matched.length > 0) {
    const alternate = getI18nPathToI18nPath(resolvedMatch.matched[0].path, locale);
    const match = matcher.resolve(
      { params: resolvedMatch.params },
      { path: alternate || "/", name: "", matched: [], params: {}, meta: {} }
    );
    const isPrefixable = prefixable(locale, defaultLocale);
    return withLeadingSlash(joinURL(isPrefixable ? locale : "", match.path));
  }
}
function prefixable(currentLocale, defaultLocale) {
  return (currentLocale !== defaultLocale || "prefix_except_default" === "prefix");
}

function* detect(detectors, detection, path) {
  if (detection.enabled) {
    yield { locale: detectors.cookie(), source: "cookie" };
    yield { locale: detectors.header(), source: "header" };
  }
  {
    yield { locale: detectors.route(path), source: "route" };
  }
  yield { locale: detection.fallbackLocale, source: "fallback" };
}
const _i79wxDEbkUNa6CIyqL_aYSDCiI35Qq1fljJiae_Onc = defineNitroPlugin(async (nitro) => {
  const runtimeI18n = useRuntimeI18n();
  const rootRedirect = resolveRootRedirect(runtimeI18n.rootRedirect);
  runtimeI18n.defaultLocale || "";
  try {
    const cacheStorage = useStorage("cache");
    const cachedKeys = await cacheStorage.getKeys("nitro:handlers:i18n");
    await Promise.all(cachedKeys.map((key) => cacheStorage.removeItem(key)));
  } catch {
  }
  const detection = useI18nDetection();
  const cookieOptions = {
    path: "/",
    domain: detection.cookieDomain || void 0,
    maxAge: 60 * 60 * 24 * 365,
    sameSite: "lax",
    secure: detection.cookieSecure
  };
  const createBaseUrlGetter = () => {
    isFunction(runtimeI18n.baseUrl) ? "" : runtimeI18n.baseUrl || "";
    if (isFunction(runtimeI18n.baseUrl)) {
      console.warn("[nuxt-i18n] Configuring baseUrl as a function is deprecated and will be removed in v11.");
      return () => "";
    }
    return (event, defaultLocale) => {
      return "";
    };
  };
  function resolveRedirectPath(event, path, pathLocale, defaultLocale, detector) {
    let locale = "";
    for (const detected of detect(detector, detection, event.path)) {
      if (detected.locale && isSupportedLocale(detected.locale)) {
        locale = detected.locale;
        break;
      }
    }
    locale ||= defaultLocale;
    function getLocalizedMatch(locale2) {
      const res = matchLocalized(path || "/", locale2, defaultLocale);
      if (res && res !== event.path) {
        return res;
      }
    }
    let resolvedPath = void 0;
    let redirectCode = 302;
    const requestURL = getRequestURL(event);
    if (rootRedirect && requestURL.pathname === "/") {
      locale = detection.enabled && locale || defaultLocale;
      resolvedPath = isSupportedLocale(detector.route(rootRedirect.path)) && rootRedirect.path || matchLocalized(rootRedirect.path, locale, defaultLocale);
      redirectCode = rootRedirect.code;
    } else if (runtimeI18n.redirectStatusCode) {
      redirectCode = runtimeI18n.redirectStatusCode;
    }
    switch (detection.redirectOn) {
      case "root":
        if (requestURL.pathname !== "/") {
          break;
        }
      // fallthrough (root has no prefix)
      case "no prefix":
        if (pathLocale) {
          break;
        }
      // fallthrough to resolve
      case "all":
        resolvedPath ??= getLocalizedMatch(locale);
        break;
    }
    if (requestURL.pathname === "/" && "prefix_except_default" === "prefix") ;
    return { path: resolvedPath, code: redirectCode, locale };
  }
  const baseUrlGetter = createBaseUrlGetter();
  nitro.hooks.hook("request", async (event) => {
    await initializeI18nContext(event);
  });
  nitro.hooks.hook("render:before", async ({ event }) => {
    const ctx = useI18nContext(event);
    const url = getRequestURL(event);
    const detector = useDetectors(event, detection);
    const localeSegment = detector.route(event.path);
    const pathLocale = isSupportedLocale(localeSegment) && localeSegment || void 0;
    const path = (pathLocale && url.pathname.slice(pathLocale.length + 1)) ?? url.pathname;
    if (!url.pathname.includes("/_i18n/BH9YmCeo") && !isExistingNuxtRoute(path)) {
      return;
    }
    const resolved = resolveRedirectPath(event, path, pathLocale, ctx.vueI18nOptions.defaultLocale, detector);
    if (resolved.path && resolved.path !== url.pathname) {
      ctx.detectLocale = resolved.locale;
      detection.useCookie && setCookie(event, detection.cookieKey, resolved.locale, cookieOptions);
      await sendRedirect(
        event,
        joinURL(baseUrlGetter(event, ctx.vueI18nOptions.defaultLocale), resolved.path + url.search),
        resolved.code
      );
      return;
    }
  });
  nitro.hooks.hook("render:html", (htmlContext, { event }) => {
    tryUseI18nContext(event);
  });
});

const rootDir = "E:/work/code/kim/ceping";

const devReducers = {
  VNode: (data) => isVNode(data) ? { type: data.type, props: data.props } : void 0,
  URL: (data) => data instanceof URL ? data.toString() : void 0
};
const asyncContext = getContext("nuxt-dev", { asyncContext: true, AsyncLocalStorage });
const _nYHi0KRxl7NB2SzBWtgP6UN_Y491NSUvmy2VaRqOcHs = (nitroApp) => {
  const handler = nitroApp.h3App.handler;
  nitroApp.h3App.handler = (event) => {
    return asyncContext.callAsync({ logs: [], event }, () => handler(event));
  };
  onConsoleLog((_log) => {
    const ctx = asyncContext.tryUse();
    if (!ctx) {
      return;
    }
    const rawStack = captureRawStackTrace();
    if (!rawStack || rawStack.includes("runtime/vite-node.mjs")) {
      return;
    }
    const trace = [];
    let filename = "";
    for (const entry of parseRawStackTrace(rawStack)) {
      if (entry.source === globalThis._importMeta_.url) {
        continue;
      }
      if (EXCLUDE_TRACE_RE.test(entry.source)) {
        continue;
      }
      filename ||= entry.source.replace(withTrailingSlash(rootDir), "");
      trace.push({
        ...entry,
        source: entry.source.startsWith("file://") ? entry.source.replace("file://", "") : entry.source
      });
    }
    const log = {
      ..._log,
      // Pass along filename to allow the client to display more info about where log comes from
      filename,
      // Clean up file names in stack trace
      stack: trace
    };
    ctx.logs.push(log);
  });
  nitroApp.hooks.hook("afterResponse", () => {
    const ctx = asyncContext.tryUse();
    if (!ctx) {
      return;
    }
    return nitroApp.hooks.callHook("dev:ssr-logs", { logs: ctx.logs, path: ctx.event.path });
  });
  nitroApp.hooks.hook("render:html", (htmlContext) => {
    const ctx = asyncContext.tryUse();
    if (!ctx) {
      return;
    }
    try {
      const reducers = Object.assign(/* @__PURE__ */ Object.create(null), devReducers, ctx.event.context._payloadReducers);
      htmlContext.bodyAppend.unshift(`<script type="application/json" data-nuxt-logs="${appId}">${stringify(ctx.logs, reducers)}<\/script>`);
    } catch (e) {
      const shortError = e instanceof Error && "toString" in e ? ` Received \`${e.toString()}\`.` : "";
      console.warn(`[nuxt] Failed to stringify dev server logs.${shortError} You can define your own reducer/reviver for rich types following the instructions in https://nuxt.com/docs/4.x/api/composables/use-nuxt-app#payload.`);
    }
  });
};
const EXCLUDE_TRACE_RE = /\/node_modules\/(?:.*\/)?(?:nuxt|nuxt-nightly|nuxt-edge|nuxt3|consola|@vue)\/|core\/runtime\/nitro/;
function onConsoleLog(callback) {
  consola$1.addReporter({
    log(logObj) {
      callback(logObj);
    }
  });
  consola$1.wrapConsole();
}

const script = "\"use strict\";(()=>{const t=window,e=document.documentElement,c=[\"dark\",\"light\"],n=getStorageValue(\"localStorage\",\"nuxt-color-mode\")||\"system\";let i=n===\"system\"?u():n;const r=e.getAttribute(\"data-color-mode-forced\");r&&(i=r),l(i),t[\"__NUXT_COLOR_MODE__\"]={preference:n,value:i,getColorScheme:u,addColorScheme:l,removeColorScheme:d};function l(o){const s=\"\"+o+\"\",a=\"\";e.classList?e.classList.add(s):e.className+=\" \"+s,a&&e.setAttribute(\"data-\"+a,o)}function d(o){const s=\"\"+o+\"\",a=\"\";e.classList?e.classList.remove(s):e.className=e.className.replace(new RegExp(s,\"g\"),\"\"),a&&e.removeAttribute(\"data-\"+a)}function f(o){return t.matchMedia(\"(prefers-color-scheme\"+o+\")\")}function u(){if(t.matchMedia&&f(\"\").media!==\"not all\"){for(const o of c)if(f(\":\"+o).matches)return o}return\"light\"}})();function getStorageValue(t,e){switch(t){case\"localStorage\":return window.localStorage.getItem(e);case\"sessionStorage\":return window.sessionStorage.getItem(e);case\"cookie\":return getCookie(e);default:return null}}function getCookie(t){const c=(\"; \"+window.document.cookie).split(\"; \"+t+\"=\");if(c.length===2)return c.pop()?.split(\";\").shift()}";

const _pDI1HtxU3VfxjhOEAvB5rgDg3qIylCVPgADdX3tZLw = (function(nitro) {
  nitro.hooks.hook("render:html", (htmlContext) => {
    htmlContext.head.push(`<script>${script}<\/script>`);
  });
});

const plugins = [
  _Hmq137YzPB4HwUUoriJKhq6Q8oE8KxmAFh5CsXLAkCU,
_i79wxDEbkUNa6CIyqL_aYSDCiI35Qq1fljJiae_Onc,
_nYHi0KRxl7NB2SzBWtgP6UN_Y491NSUvmy2VaRqOcHs,
_pDI1HtxU3VfxjhOEAvB5rgDg3qIylCVPgADdX3tZLw
];

const assets = {};

function readAsset (id) {
  const serverDir = dirname$1(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve$1(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta/":{"maxAge":31536000},"/_nuxt/builds/":{"maxAge":1}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _Xphl1k = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError({ statusCode: 404 });
    }
    return;
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

const VueResolver = (_, value) => {
  return isRef(value) ? toValue(value) : value;
};

const headSymbol = "usehead";
// @__NO_SIDE_EFFECTS__
function vueInstall(head) {
  const plugin = {
    install(app) {
      app.config.globalProperties.$unhead = head;
      app.config.globalProperties.$head = head;
      app.provide(headSymbol, head);
    }
  };
  return plugin.install;
}

// @__NO_SIDE_EFFECTS__
function resolveUnrefHeadInput(input) {
  return walkResolver(input, VueResolver);
}

// @__NO_SIDE_EFFECTS__
function createHead(options = {}) {
  const head = createHead$1({
    ...options,
    propResolvers: [VueResolver]
  });
  head.install = vueInstall(head);
  return head;
}

const unheadOptions = {
  disableDefaults: true,
};

function createSSRContext(event) {
  const ssrContext = {
    url: event.path,
    event,
    runtimeConfig: useRuntimeConfig(event),
    noSSR: event.context.nuxt?.noSSR || (false),
    head: createHead(unheadOptions),
    error: false,
    nuxt: void 0,
    /* NuxtApp */
    payload: {},
    _payloadReducers: /* @__PURE__ */ Object.create(null),
    modules: /* @__PURE__ */ new Set()
  };
  return ssrContext;
}
function setSSRError(ssrContext, error) {
  ssrContext.error = true;
  ssrContext.payload = { error };
  ssrContext.url = error.url;
}

const APP_ROOT_OPEN_TAG = `<${appRootTag}${propsToString(appRootAttrs)}>`;
const APP_ROOT_CLOSE_TAG = `</${appRootTag}>`;
const getServerEntry = () => import('file://E:/work/code/kim/ceping/.nuxt//dist/server/server.mjs').then((r) => r.default || r);
const getClientManifest = () => import('file://E:/work/code/kim/ceping/.nuxt//dist/server/client.manifest.mjs').then((r) => r.default || r).then((r) => typeof r === "function" ? r() : r);
const getSSRRenderer = lazyCachedFunction(async () => {
  const createSSRApp = await getServerEntry();
  if (!createSSRApp) {
    throw new Error("Server bundle is not available");
  }
  const precomputed = void 0 ;
  const renderer = createRenderer(createSSRApp, {
    precomputed,
    manifest: await getClientManifest() ,
    renderToString: renderToString$1,
    buildAssetsURL
  });
  async function renderToString$1(input, context) {
    const html = await renderToString(input, context);
    if (process$1.env.NUXT_VITE_NODE_OPTIONS) {
      renderer.rendererContext.updateManifest(await getClientManifest());
    }
    return APP_ROOT_OPEN_TAG + html + APP_ROOT_CLOSE_TAG;
  }
  return renderer;
});
const getSPARenderer = lazyCachedFunction(async () => {
  const precomputed = void 0 ;
  const spaTemplate = await Promise.resolve().then(function () { return _virtual__spaTemplate; }).then((r) => r.template).catch(() => "").then((r) => {
    {
      const APP_SPA_LOADER_OPEN_TAG = `<${appSpaLoaderTag}${propsToString(appSpaLoaderAttrs)}>`;
      const APP_SPA_LOADER_CLOSE_TAG = `</${appSpaLoaderTag}>`;
      const appTemplate = APP_ROOT_OPEN_TAG + APP_ROOT_CLOSE_TAG;
      const loaderTemplate = r ? APP_SPA_LOADER_OPEN_TAG + r + APP_SPA_LOADER_CLOSE_TAG : "";
      return appTemplate + loaderTemplate;
    }
  });
  const renderer = createRenderer(() => () => {
  }, {
    precomputed,
    manifest: await getClientManifest() ,
    renderToString: () => spaTemplate,
    buildAssetsURL
  });
  const result = await renderer.renderToString({});
  const renderToString = (ssrContext) => {
    const config = useRuntimeConfig(ssrContext.event);
    ssrContext.modules ||= /* @__PURE__ */ new Set();
    ssrContext.payload.serverRendered = false;
    ssrContext.config = {
      public: config.public,
      app: config.app
    };
    return Promise.resolve(result);
  };
  return {
    rendererContext: renderer.rendererContext,
    renderToString
  };
});
function lazyCachedFunction(fn) {
  let res = null;
  return () => {
    if (res === null) {
      res = fn().catch((err) => {
        res = null;
        throw err;
      });
    }
    return res;
  };
}
function getRenderer(ssrContext) {
  return ssrContext.noSSR ? getSPARenderer() : getSSRRenderer();
}
const getSSRStyles = lazyCachedFunction(() => Promise.resolve().then(function () { return styles$1; }).then((r) => r.default || r));

async function renderInlineStyles(usedModules) {
  const styleMap = await getSSRStyles();
  const inlinedStyles = /* @__PURE__ */ new Set();
  for (const mod of usedModules) {
    if (mod in styleMap && styleMap[mod]) {
      for (const style of await styleMap[mod]()) {
        inlinedStyles.add(style);
      }
    }
  }
  return Array.from(inlinedStyles).map((style) => ({ innerHTML: style }));
}

const ROOT_NODE_REGEX = new RegExp(`^<${appRootTag}[^>]*>([\\s\\S]*)<\\/${appRootTag}>$`);
function getServerComponentHTML(body) {
  const match = body.match(ROOT_NODE_REGEX);
  return match?.[1] || body;
}
const SSR_SLOT_TELEPORT_MARKER = /^uid=([^;]*);slot=(.*)$/;
const SSR_CLIENT_TELEPORT_MARKER = /^uid=([^;]*);client=(.*)$/;
const SSR_CLIENT_SLOT_MARKER = /^island-slot=([^;]*);(.*)$/;
function getSlotIslandResponse(ssrContext) {
  if (!ssrContext.islandContext || !Object.keys(ssrContext.islandContext.slots).length) {
    return void 0;
  }
  const response = {};
  for (const [name, slot] of Object.entries(ssrContext.islandContext.slots)) {
    response[name] = {
      ...slot,
      fallback: ssrContext.teleports?.[`island-fallback=${name}`]
    };
  }
  return response;
}
function getClientIslandResponse(ssrContext) {
  if (!ssrContext.islandContext || !Object.keys(ssrContext.islandContext.components).length) {
    return void 0;
  }
  const response = {};
  for (const [clientUid, component] of Object.entries(ssrContext.islandContext.components)) {
    const html = ssrContext.teleports?.[clientUid]?.replaceAll("<!--teleport start anchor-->", "") || "";
    response[clientUid] = {
      ...component,
      html,
      slots: getComponentSlotTeleport(clientUid, ssrContext.teleports ?? {})
    };
  }
  return response;
}
function getComponentSlotTeleport(clientUid, teleports) {
  const entries = Object.entries(teleports);
  const slots = {};
  for (const [key, value] of entries) {
    const match = key.match(SSR_CLIENT_SLOT_MARKER);
    if (match) {
      const [, id, slot] = match;
      if (!slot || clientUid !== id) {
        continue;
      }
      slots[slot] = value;
    }
  }
  return slots;
}
function replaceIslandTeleports(ssrContext, html) {
  const { teleports, islandContext } = ssrContext;
  if (islandContext || !teleports) {
    return html;
  }
  for (const key in teleports) {
    const matchClientComp = key.match(SSR_CLIENT_TELEPORT_MARKER);
    if (matchClientComp) {
      const [, uid, clientId] = matchClientComp;
      if (!uid || !clientId) {
        continue;
      }
      html = html.replace(new RegExp(` data-island-uid="${uid}" data-island-component="${clientId}"[^>]*>`), (full) => {
        return full + teleports[key];
      });
      continue;
    }
    const matchSlot = key.match(SSR_SLOT_TELEPORT_MARKER);
    if (matchSlot) {
      const [, uid, slot] = matchSlot;
      if (!uid || !slot) {
        continue;
      }
      html = html.replace(new RegExp(` data-island-uid="${uid}" data-island-slot="${slot}"[^>]*>`), (full) => {
        return full + teleports[key];
      });
    }
  }
  return html;
}

const ISLAND_SUFFIX_RE = /\.json(?:\?.*)?$/;
const _SxA8c9 = defineEventHandler(async (event) => {
  const nitroApp = useNitroApp();
  setResponseHeaders(event, {
    "content-type": "application/json;charset=utf-8",
    "x-powered-by": "Nuxt"
  });
  const islandContext = await getIslandContext(event);
  const ssrContext = {
    ...createSSRContext(event),
    islandContext,
    noSSR: false,
    url: islandContext.url
  };
  const renderer = await getSSRRenderer();
  const renderResult = await renderer.renderToString(ssrContext).catch(async (err) => {
    await ssrContext.nuxt?.hooks.callHook("app:error", err);
    throw err;
  });
  if (ssrContext.payload?.error) {
    throw ssrContext.payload.error;
  }
  const inlinedStyles = await renderInlineStyles(ssrContext.modules ?? []);
  await ssrContext.nuxt?.hooks.callHook("app:rendered", { ssrContext, renderResult });
  if (inlinedStyles.length) {
    ssrContext.head.push({ style: inlinedStyles });
  }
  {
    const { styles } = getRequestDependencies(ssrContext, renderer.rendererContext);
    const link = [];
    for (const resource of Object.values(styles)) {
      if ("inline" in getQuery(resource.file)) {
        continue;
      }
      if (resource.file.includes("scoped") && !resource.file.includes("pages/")) {
        link.push({ rel: "stylesheet", href: renderer.rendererContext.buildAssetsURL(resource.file), crossorigin: "" });
      }
    }
    if (link.length) {
      ssrContext.head.push({ link }, { mode: "server" });
    }
  }
  const islandHead = {};
  for (const entry of ssrContext.head.entries.values()) {
    for (const [key, value] of Object.entries(resolveUnrefHeadInput(entry.input))) {
      const currentValue = islandHead[key];
      if (Array.isArray(currentValue)) {
        currentValue.push(...value);
      }
      islandHead[key] = value;
    }
  }
  const islandResponse = {
    id: islandContext.id,
    head: islandHead,
    html: getServerComponentHTML(renderResult.html),
    components: getClientIslandResponse(ssrContext),
    slots: getSlotIslandResponse(ssrContext)
  };
  await nitroApp.hooks.callHook("render:island", islandResponse, { event, islandContext });
  return islandResponse;
});
async function getIslandContext(event) {
  let url = event.path || "";
  const componentParts = url.substring("/__nuxt_island".length + 1).replace(ISLAND_SUFFIX_RE, "").split("_");
  const hashId = componentParts.length > 1 ? componentParts.pop() : void 0;
  const componentName = componentParts.join("_");
  const context = event.method === "GET" ? getQuery$1(event) : await readBody(event);
  const ctx = {
    url: "/",
    ...context,
    id: hashId,
    name: componentName,
    props: destr$1(context.props) || {},
    slots: {},
    components: {}
  };
  return ctx;
}

const warnOnceSet = /* @__PURE__ */ new Set();
const DEFAULT_ENDPOINT = "https://api.iconify.design";
const _RE9U5Y = defineCachedEventHandler(async (event) => {
  const url = getRequestURL(event);
  if (!url)
    return createError({ status: 400, message: "Invalid icon request" });
  const options = useAppConfig().icon;
  const collectionName = event.context.params?.collection?.replace(/\.json$/, "");
  const collection = collectionName ? await collections[collectionName]?.() : null;
  const apiEndPoint = options.iconifyApiEndpoint || DEFAULT_ENDPOINT;
  const icons = url.searchParams.get("icons")?.split(",");
  if (collection) {
    if (icons?.length) {
      const data = getIcons(
        collection,
        icons
      );
      consola$1.debug(`[Icon] serving ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from bundled collection`);
      return data;
    }
  } else {
    if (collectionName && !warnOnceSet.has(collectionName) && apiEndPoint === DEFAULT_ENDPOINT) {
      consola$1.warn([
        `[Icon] Collection \`${collectionName}\` is not found locally`,
        `We suggest to install it via \`npm i -D @iconify-json/${collectionName}\` to provide the best end-user experience.`
      ].join("\n"));
      warnOnceSet.add(collectionName);
    }
  }
  if (options.fallbackToApi === true || options.fallbackToApi === "server-only") {
    const apiUrl = new URL("./" + basename(url.pathname) + url.search, apiEndPoint);
    consola$1.debug(`[Icon] fetching ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from iconify api`);
    if (apiUrl.host !== new URL(apiEndPoint).host) {
      return createError({ status: 400, message: "Invalid icon request" });
    }
    try {
      const data = await $fetch(apiUrl.href);
      return data;
    } catch (e) {
      consola$1.error(e);
      if (e.status === 404)
        return createError({ status: 404 });
      else
        return createError({ status: 500, message: "Failed to fetch fallback icon" });
    }
  }
  return createError({ status: 404 });
}, {
  group: "nuxt",
  name: "icon",
  getKey(event) {
    const collection = event.context.params?.collection?.replace(/\.json$/, "") || "unknown";
    const icons = String(getQuery$1(event).icons || "");
    return `${collection}_${icons.split(",")[0]}_${icons.length}_${hash$1(icons)}`;
  },
  swr: true,
  maxAge: 60 * 60 * 24 * 7
  // 1 week
});

const storage = prefixStorage(useStorage(), "i18n");
function cachedFunctionI18n(fn, opts) {
  opts = { maxAge: 1, ...opts };
  const pending = {};
  async function get(key, resolver) {
    const isPending = pending[key];
    if (!isPending) {
      pending[key] = Promise.resolve(resolver());
    }
    try {
      return await pending[key];
    } finally {
      delete pending[key];
    }
  }
  return async (...args) => {
    const key = [opts.name, opts.getKey(...args)].join(":").replace(/:\/$/, ":index");
    const maxAge = opts.maxAge ?? 1;
    const isCacheable = !opts.shouldBypassCache(...args) && maxAge >= 0;
    const cache = isCacheable && await storage.getItemRaw(key);
    if (!cache || cache.ttl < Date.now()) {
      pending[key] = Promise.resolve(fn(...args));
      const value = await get(key, () => fn(...args));
      if (isCacheable) {
        await storage.setItemRaw(key, { ttl: Date.now() + maxAge * 1e3, value, mtime: Date.now() });
      }
      return value;
    }
    return cache.value;
  };
}

const _getMessages = async (locale) => {
  return { [locale]: await getLocaleMessagesMerged(locale, localeLoaders[locale]) };
};
cachedFunctionI18n(_getMessages, {
  name: "messages",
  maxAge: -1 ,
  getKey: (locale) => locale,
  shouldBypassCache: (locale) => !isLocaleCacheable(locale)
});
const getMessages = _getMessages ;
const _getMergedMessages = async (locale, fallbackLocales) => {
  const merged = {};
  try {
    if (fallbackLocales.length > 0) {
      const messages = await Promise.all(fallbackLocales.map(getMessages));
      for (const message2 of messages) {
        deepCopy(message2, merged);
      }
    }
    const message = await getMessages(locale);
    deepCopy(message, merged);
    return merged;
  } catch (e) {
    throw new Error("Failed to merge messages: " + e.message);
  }
};
const getMergedMessages = cachedFunctionI18n(_getMergedMessages, {
  name: "merged-single",
  maxAge: -1 ,
  getKey: (locale, fallbackLocales) => `${locale}-[${[...new Set(fallbackLocales)].sort().join("-")}]`,
  shouldBypassCache: (locale, fallbackLocales) => !isLocaleWithFallbacksCacheable(locale, fallbackLocales)
});
const _getAllMergedMessages = async (locales) => {
  const merged = {};
  try {
    const messages = await Promise.all(locales.map(getMessages));
    for (const message of messages) {
      deepCopy(message, merged);
    }
    return merged;
  } catch (e) {
    throw new Error("Failed to merge messages: " + e.message);
  }
};
cachedFunctionI18n(_getAllMergedMessages, {
  name: "merged-all",
  maxAge: -1 ,
  getKey: (locales) => locales.join("-"),
  shouldBypassCache: (locales) => !locales.every((locale) => isLocaleCacheable(locale))
});

const _messagesHandler = defineEventHandler(async (event) => {
  const locale = getRouterParam(event, "locale");
  if (!locale) {
    throw createError({ status: 400, message: "Locale not specified." });
  }
  const ctx = useI18nContext(event);
  if (ctx.localeConfigs && locale in ctx.localeConfigs === false) {
    throw createError({ status: 404, message: `Locale '${locale}' not found.` });
  }
  const messages = await getMergedMessages(locale, ctx.localeConfigs?.[locale]?.fallbacks ?? []);
  deepCopy(messages, ctx.messages);
  return ctx.messages;
});
const _cachedMessageLoader = defineCachedFunction(_messagesHandler, {
  name: "i18n:messages-internal",
  maxAge: -1 ,
  getKey: (event) => [getRouterParam(event, "locale") ?? "null", getRouterParam(event, "hash") ?? "null"].join("-"),
  async shouldBypassCache(event) {
    const locale = getRouterParam(event, "locale");
    if (locale == null) {
      return false;
    }
    const ctx = tryUseI18nContext(event) || await initializeI18nContext(event);
    return !ctx.localeConfigs?.[locale]?.cacheable;
  }
});
defineCachedEventHandler(_cachedMessageLoader, {
  name: "i18n:messages",
  maxAge: -1 ,
  swr: false,
  getKey: (event) => [getRouterParam(event, "locale") ?? "null", getRouterParam(event, "hash") ?? "null"].join("-")
});
const _QIjFIy = _messagesHandler ;

const _l1i_Wy = lazyEventHandler(() => {
  const opts = useRuntimeConfig().ipx || {};
  const fsDir = opts?.fs?.dir ? (Array.isArray(opts.fs.dir) ? opts.fs.dir : [opts.fs.dir]).map((dir) => isAbsolute(dir) ? dir : fileURLToPath(new URL(dir, globalThis._importMeta_.url))) : void 0;
  const fsStorage = opts.fs?.dir ? ipxFSStorage({ ...opts.fs, dir: fsDir }) : void 0;
  const httpStorage = opts.http?.domains ? ipxHttpStorage({ ...opts.http }) : void 0;
  if (!fsStorage && !httpStorage) {
    throw new Error("IPX storage is not configured!");
  }
  const ipxOptions = {
    ...opts,
    storage: fsStorage || httpStorage,
    httpStorage
  };
  const ipx = createIPX(ipxOptions);
  const ipxHandler = createIPXH3Handler(ipx);
  return useBase(opts.baseURL, ipxHandler);
});

const _lazy_N45kBK = () => Promise.resolve().then(function () { return renderer$1; });

const handlers = [
  { route: '', handler: _Xphl1k, lazy: false, middleware: true, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_N45kBK, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_island/**', handler: _SxA8c9, lazy: false, middleware: false, method: undefined },
  { route: '/api/_nuxt_icon/:collection', handler: _RE9U5Y, lazy: false, middleware: false, method: undefined },
  { route: '/_i18n/:hash/:locale/messages.json', handler: _QIjFIy, lazy: false, middleware: false, method: undefined },
  { route: '/_ipx/**', handler: _l1i_Wy, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_N45kBK, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(true),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp$1.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter$1({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => callNodeRequestHandler(
    nodeHandler,
    aRequest
  );
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return fetchNodeRequestHandler(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp$1 = createNitroApp();
function useNitroApp() {
  return nitroApp$1;
}
runNitroPlugins(nitroApp$1);

if (!globalThis.crypto) {
  globalThis.crypto = nodeCrypto;
}
const { NITRO_NO_UNIX_SOCKET, NITRO_DEV_WORKER_ID } = process.env;
trapUnhandledNodeErrors();
parentPort?.on("message", (msg) => {
  if (msg && msg.event === "shutdown") {
    shutdown();
  }
});
const nitroApp = useNitroApp();
const server = new Server(toNodeListener(nitroApp.h3App));
let listener;
listen().catch(() => listen(
  true
  /* use random port */
)).catch((error) => {
  console.error("Dev worker failed to listen:", error);
  return shutdown();
});
nitroApp.router.get(
  "/_nitro/tasks",
  defineEventHandler(async (event) => {
    const _tasks = await Promise.all(
      Object.entries(tasks).map(async ([name, task]) => {
        const _task = await task.resolve?.();
        return [name, { description: _task?.meta?.description }];
      })
    );
    return {
      tasks: Object.fromEntries(_tasks),
      scheduledTasks
    };
  })
);
nitroApp.router.use(
  "/_nitro/tasks/:name",
  defineEventHandler(async (event) => {
    const name = getRouterParam(event, "name");
    const payload = {
      ...getQuery$1(event),
      ...await readBody(event).then((r) => r?.payload).catch(() => ({}))
    };
    return await runTask(name, { payload });
  })
);
function listen(useRandomPort = Boolean(
  NITRO_NO_UNIX_SOCKET || process.versions.webcontainer || "Bun" in globalThis && process.platform === "win32"
)) {
  return new Promise((resolve, reject) => {
    try {
      listener = server.listen(useRandomPort ? 0 : getSocketAddress(), () => {
        const address = server.address();
        parentPort?.postMessage({
          event: "listen",
          address: typeof address === "string" ? { socketPath: address } : { host: "localhost", port: address?.port }
        });
        resolve();
      });
    } catch (error) {
      reject(error);
    }
  });
}
function getSocketAddress() {
  const socketName = `nitro-worker-${process.pid}-${threadId}-${NITRO_DEV_WORKER_ID}-${Math.round(Math.random() * 1e4)}.sock`;
  if (process.platform === "win32") {
    return join(String.raw`\\.\pipe`, socketName);
  }
  if (process.platform === "linux") {
    const nodeMajor = Number.parseInt(process.versions.node.split(".")[0], 10);
    if (nodeMajor >= 20) {
      return `\0${socketName}`;
    }
  }
  return join(tmpdir(), socketName);
}
async function shutdown() {
  server.closeAllConnections?.();
  await Promise.all([
    new Promise((resolve) => listener?.close(resolve)),
    nitroApp.hooks.callHook("close").catch(console.error)
  ]);
  parentPort?.postMessage({ event: "exit" });
}

const _messages = { "appName": "Nuxt", "statusCode": 500, "statusMessage": "Internal server error", "description": "This page is temporarily unavailable.", "refresh": "Refresh this page" };
const template$1 = (messages) => {
  messages = { ..._messages, ...messages };
  return '<!DOCTYPE html><html lang="en"><head><title>' + escapeHtml(messages.statusCode) + " - " + escapeHtml(messages.statusMessage) + " | " + escapeHtml(messages.appName) + `</title><meta charset="utf-8"><meta content="width=device-width,initial-scale=1.0,minimum-scale=1.0" name="viewport"><script>!function(){const e=document.createElement("link").relList;if(!(e&&e.supports&&e.supports("modulepreload"))){for(const e of document.querySelectorAll('link[rel="modulepreload"]'))r(e);new MutationObserver(e=>{for(const o of e)if("childList"===o.type)for(const e of o.addedNodes)"LINK"===e.tagName&&"modulepreload"===e.rel&&r(e)}).observe(document,{childList:!0,subtree:!0})}function r(e){if(e.ep)return;e.ep=!0;const r=function(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerPolicy&&(r.referrerPolicy=e.referrerPolicy),"use-credentials"===e.crossOrigin?r.credentials="include":"anonymous"===e.crossOrigin?r.credentials="omit":r.credentials="same-origin",r}(e);fetch(e.href,r)}}();<\/script><style>*,:after,:before{border-color:var(--un-default-border-color,#e5e7eb);border-style:solid;border-width:0;box-sizing:border-box}:after,:before{--un-content:""}html{line-height:1.5;-webkit-text-size-adjust:100%;font-family:ui-sans-serif,system-ui,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;font-feature-settings:normal;font-variation-settings:normal;-moz-tab-size:4;tab-size:4;-webkit-tap-highlight-color:transparent}body{line-height:inherit;margin:0}h1,h2{font-size:inherit;font-weight:inherit}h1,h2,p{margin:0}*,:after,:before{--un-rotate:0;--un-rotate-x:0;--un-rotate-y:0;--un-rotate-z:0;--un-scale-x:1;--un-scale-y:1;--un-scale-z:1;--un-skew-x:0;--un-skew-y:0;--un-translate-x:0;--un-translate-y:0;--un-translate-z:0;--un-pan-x: ;--un-pan-y: ;--un-pinch-zoom: ;--un-scroll-snap-strictness:proximity;--un-ordinal: ;--un-slashed-zero: ;--un-numeric-figure: ;--un-numeric-spacing: ;--un-numeric-fraction: ;--un-border-spacing-x:0;--un-border-spacing-y:0;--un-ring-offset-shadow:0 0 transparent;--un-ring-shadow:0 0 transparent;--un-shadow-inset: ;--un-shadow:0 0 transparent;--un-ring-inset: ;--un-ring-offset-width:0px;--un-ring-offset-color:#fff;--un-ring-width:0px;--un-ring-color:rgba(147,197,253,.5);--un-blur: ;--un-brightness: ;--un-contrast: ;--un-drop-shadow: ;--un-grayscale: ;--un-hue-rotate: ;--un-invert: ;--un-saturate: ;--un-sepia: ;--un-backdrop-blur: ;--un-backdrop-brightness: ;--un-backdrop-contrast: ;--un-backdrop-grayscale: ;--un-backdrop-hue-rotate: ;--un-backdrop-invert: ;--un-backdrop-opacity: ;--un-backdrop-saturate: ;--un-backdrop-sepia: }.grid{display:grid}.mb-2{margin-bottom:.5rem}.mb-4{margin-bottom:1rem}.max-w-520px{max-width:520px}.min-h-screen{min-height:100vh}.place-content-center{place-content:center}.overflow-hidden{overflow:hidden}.bg-white{--un-bg-opacity:1;background-color:rgb(255 255 255/var(--un-bg-opacity))}.px-2{padding-left:.5rem;padding-right:.5rem}.text-center{text-align:center}.text-\\[80px\\]{font-size:80px}.text-2xl{font-size:1.5rem;line-height:2rem}.text-\\[\\#020420\\]{--un-text-opacity:1;color:rgb(2 4 32/var(--un-text-opacity))}.text-\\[\\#64748B\\]{--un-text-opacity:1;color:rgb(100 116 139/var(--un-text-opacity))}.font-semibold{font-weight:600}.leading-none{line-height:1}.tracking-wide{letter-spacing:.025em}.font-sans{font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji}.tabular-nums{--un-numeric-spacing:tabular-nums;font-variant-numeric:var(--un-ordinal) var(--un-slashed-zero) var(--un-numeric-figure) var(--un-numeric-spacing) var(--un-numeric-fraction)}.antialiased{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}@media(prefers-color-scheme:dark){.dark\\:bg-\\[\\#020420\\]{--un-bg-opacity:1;background-color:rgb(2 4 32/var(--un-bg-opacity))}.dark\\:text-white{--un-text-opacity:1;color:rgb(255 255 255/var(--un-text-opacity))}}@media(min-width:640px){.sm\\:text-\\[110px\\]{font-size:110px}.sm\\:text-3xl{font-size:1.875rem;line-height:2.25rem}}</style></head><body class="antialiased bg-white dark:bg-[#020420] dark:text-white font-sans grid min-h-screen overflow-hidden place-content-center text-[#020420] tracking-wide"><div class="max-w-520px text-center"><h1 class="font-semibold leading-none mb-4 sm:text-[110px] tabular-nums text-[80px]">` + escapeHtml(messages.statusCode) + '</h1><h2 class="font-semibold mb-2 sm:text-3xl text-2xl">' + escapeHtml(messages.statusMessage) + '</h2><p class="mb-4 px-2 text-[#64748B] text-md">' + escapeHtml(messages.description) + "</p></div></body></html>";
};

const error500 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  template: template$1
}, Symbol.toStringTag, { value: 'Module' }));

var contact$1 = {
	title: "Contact Us",
	desc1: "Have questions about our personality tests or need support?",
	desc2: "Contact the PersonalityTest101 team — we’re here to help.",
	support: "Test Support",
	supportDesc: "Get help with taking personality tests, viewing results, or understanding your reports.",
	media: "Feedback & Suggestions",
	mediaDesc: "Share your thoughts, ideas, or suggestions to help us improve PersonalityTest101.",
	feedback: "General Inquiries",
	feedbackDesc: "Have questions about PersonalityTest101 or our services? Reach out and we'll get back to you as soon as possible.",
	contactUs: "Get in Touch",
	contactDesc1: "Your feedback is greatly appreciated. If you have questions about our personality tests, need assistance, or want to share feedback, feel free to reach out anytime. We're always happy to hear from our users and provide clear, thoughtful support.",
	contactDesc2: "You may also find helpful information in our FAQ section, where we provide a comprehensive overview of our services and operations. If you cannot find a satisfactory answer, please email us and our support team will respond within 24 hours.",
	getSupport: "Contact Support",
	faqTitle: "Frequently Asked Questions",
	faqDesc: "Have questions about our personality tests or how PersonalityTest101 works? Here are some of the most common questions we get — with clear,  easy-to-understand answers to help you get started.",
	curiousTitle: "Ready to Uncover Your True Personality?",
	curiousDesc: "Find out your personality type, preferences, and hidden strengths in just a few minutes. Quick, fun, and insightful — your journey of self-discovery starts here!",
	curiousButtonText: "Reveal Your Personality"
};
var about$1 = {
	hero: {
		title: "Empowering Self-Discovery Through Precision",
		desc: "PersonalityTest101 delivers science-backed assessments to decode your unique traits. We translate complex behavioral data into actionable insights, helping you navigate your personal and professional growth with confidence."
	},
	sections: {
		mission: {
			badge: "Our Mission ",
			title: "Unveiling the Layers of Your Personality",
			desc: "Mission Statement: Our mission is to guide individuals on a journey of deep self-understanding and personal growth. By leveraging profound insights from our meticulously crafted personality assessments, we aim to illuminate the unique behavioral patterns that define each individual. We believe in the transformative power of self-knowledge to enhance relationships, promote mental well-being, and foster a fulfilling life.",
			list1: "Fostering Personal Growth & Self-Awareness ",
			list2: "Innovating Precision-Based Assessments ",
			list3: "User-Centric Insight Delivery ",
			list4: "Empowering Stronger Human Connections"
		},
		vision: {
			badge: "Our Vision ",
			title: "A Trusted Partner in Your Journey of Discovery",
			desc: "Vision Statement: Our vision is to become the global standard for personal and professional growth through psychological precision. We strive to create a world where self-awareness is the foundation for every decision, empowering a community that thrives on clarity, empathy, and continuous development.",
			list1: "Evidence-Based Insights ",
			list2: "Psychological Innovation ",
			list3: "User-Centric Growth ",
			list4: "Strengthening Human Connections "
		}
	},
	stats: {
		projects: {
			value: "150+",
			label: "Assessment Frameworks"
		},
		team: {
			value: "100+",
			label: "Behavioral Experts"
		},
		reviews: {
			value: "200K+",
			label: "Verified User Insights"
		},
		awards: {
			value: "30+",
			label: "Global Industry Awards"
		}
	},
	content: {
		desc: "At PersonalityTest101, we are committed to revolutionizing self-discovery with science-backed, accessible, and transformative insights. By combining psychological expertise with advanced data analytics, we provide the clarity you need to master your strengths and achieve your personal goals."
	},
	faq: {
		title: "Frequently Asked Questions",
		desc: "Find quick answers to common inquiries regarding our assessment process, report insights, and platform features.",
		q1: "How accurate are the personality test results?",
		a1: "Our assessments are built on validated psychological frameworks and refined through data science to ensure high reliability. While no test can capture every nuance, 95% of our users report that their results provide a highly accurate reflection of their core traits and behaviors.",
		q2: " Can I access my reports from any device?",
		a2: "Yes, your PersonalityTest101 dashboard is fully responsive. You can complete tests on your mobile device and later access your detailed PDF reports or interactive insights from your tablet or desktop at any time.",
		q3: "Is my personal data and test history secure?",
		a3: "Privacy is our priority. We use industry-standard encryption to protect your data. Your individual results are never shared with third parties without your explicit consent, ensuring a safe space for your self-discovery journey.",
		q4: "How can I use these insights in my professional life?",
		a4: "Your report includes a dedicated section on workplace dynamics. It provides actionable strategies for leadership, communication, and team collaboration, helping you leverage your natural strengths to advance your career.",
		q5: "5.Are there different types of tests available?",
		a5: "Yes! PersonalityTest101 offers a variety of assessments that explore different aspects of your personality, including traits, strengths, career preferences, and relationship patterns. You can choose the tests that interest you most."
	},
	standout: {
		title: "Precision, Depth, and Clarity: The Gold Standard of Personality Assessment",
		desc: "Our methodology integrates psychological expertise with advanced behavioral analytics to deliver high-fidelity insights. We focus on the intricate details of your personality to ensure a transformative and meaningful journey of self-discovery.",
		items: {
			precision: {
				title: "Psychological Precision",
				desc: "Developed by behavioral scientists to ensure the highest accuracy in every assessment result."
			},
			deep: {
				title: "Deep Insights",
				desc: "Move beyond the surface with in-depth analysis tailored to your unique personal and professional growth."
			},
			expert: {
				title: "Expert Guidance",
				desc: "Unlock actionable clarity through comprehensive reports and expert-backed resources designed for lasting impact."
			}
		}
	}
};
var auth$1 = {
	signIn: {
		title: "Sign In",
		description: "Securely access your account.",
		passwordLabel: "Password",
		passwordPlaceholder: "Enter your password",
		emailPlaceholder: "Enter your email address",
		submit: "Continue",
		noAccount: "Don't have an account?",
		signUp: "Sign Up"
	}
};
var faq$3 = {
	title: "Personality Test FAQs",
	integration: "Integration",
	general: {
		faqs: "General FAQs"
	},
	integrations: {
		title1: "How We Use Your Information",
		title2: "Data Sharing and Disclosure",
		title3: "Cookies and Tracking Technologies",
		title4: "Changes to This Privacy Policy",
		title5: "Contact Us",
		list1: {
			question1: "How is my personal assessment data utilized?",
			answer1: "We use your responses to generate your comprehensive personality archetype and provide personalized growth insights. Your data also helps us refine our psychometric algorithms to ensure the highest level of accuracy for all users."
		},
		list2: {
			question1: "Will my individual test results be shared with third parties?",
			answer1: "We do not sell your personal data or test results to anyone. Information is only shared with trusted service providers (e.g., payment processors) to facilitate our services. All such parties are bound by strict confidentiality agreements."
		},
		list3: {
			question1: "Why does the platform use cookies and tracking tools?",
			answer1: "Cookies allow us to recognize your session and sync your premium reports across multiple devices. We also use these technologies to analyze site performance and deliver a more seamless, personalized user experience."
		},
		list4: {
			question1: "How will I be informed of updates to the Privacy Policy?",
			answer1: "As privacy laws evolve, we may update our terms. Any significant changes will be communicated to you via the email address linked to your account or through a prominent notice on our member dashboard."
		},
		list5: {
			question1: "How can I reach support regarding privacy or billing?",
			answer1: "Our dedicated support team is available 24/7. You can use the \"Contact Us\" form located at the bottom of the page or email us directly at <a href=\"mailto:{email}\">{email}</a>. We strive to respond to all inquiries within 24 hours."
		},
		list: {
			"1": {
				q: "Platform & Sharing",
				desc: "Can I sync my results with my LinkedIn profile?  Yes, premium members can generate a \"Professional Summary\" badge that can be easily shared or linked to your LinkedIn and other professional portfolios."
			},
			"2": {
				q: "How do I invite my partner or team to compare results? ",
				desc: "Inside your dashboard, use the \"Invite to Compare\" feature. You can view compatibility reports once both parties have completed their assessments."
			},
			"3": {
				q: "Is there a mobile app available? ",
				desc: "While we don't have a standalone app yet, our website is fully mobile-optimized, allowing you to access all your reports and tools on the go."
			},
			"4": {
				q: "What should I do if my report didn't generate? ",
				desc: "This is rare, but if it happens, try refreshing the page or checking your email for a direct link. You can also contact our support for an immediate manual reset."
			},
			"5": {
				q: "Can I hide my results from search engines? ",
				desc: "Absolutely. Your privacy is our priority. All test results are set to \"Private\" by default and will never appear in public search results."
			},
			"6": {
				q: "How do I update my account email or password? ",
				desc: "You can manage all your personal information under the Account Settings > Profile section at any time."
			}
		},
		type2: "(2)Technical & Privacy",
		type1: "(1)Platform & Sharing"
	},
	faqs: {
		personalityScience: "Personality & Science",
		membershipBilling: "Membership & Billing",
		list: {
			"1": {
				q: "What psychological models do you use?",
				desc: "Our core assessments are based on the Five-Factor Model (Big Five) and Jungian typology, ensuring a balance between scientific rigor and practical insights."
			},
			"2": {
				q: "Can my personality type change over time?",
				desc: "While core traits tend to be stable, your behaviors and coping mechanisms evolve. We recommend retaking the test every 6 months to track your personal growth."
			},
			"3": {
				q: "Is this test suitable for professional career planning?",
				desc: "Yes. Our Premium reports include a \"Career Architect\" section that matches your traits with 100+ professional paths and workplace environments."
			},
			"4": {
				q: "Why is there a charge for premium results?",
				desc: "The $1.99 covers the cost of our advanced analytical engine and allows us to provide a high-quality, ad-free experience with personalized growth tools."
			},
			"5": {
				q: "What happens if I forget to cancel my trial?",
				desc: "We send a reminder email 24 hours before your trial ends. If you miss it, our 30-day money-back guarantee still applies to your first monthly charge."
			},
			"6": {
				q: "Do you offer a one-time purchase option?",
				desc: "Currently, we focus on a membership model to provide ongoing value, including weekly updated content and long-term trait tracking."
			}
		}
	}
};
var test$1 = {
	index: {
		title: "Free Personality Test",
		step1: {
			title: "Complete the Test",
			desc: "Answer intuitively to reveal your unique personality blueprint."
		},
		step2: {
			title: "Detailed Results",
			desc: "Get deep insights into how your traits influence your life."
		},
		step3: {
			title: "Grow Your Potential",
			desc: "Unlock tailored guidance to align your career and strengths."
		},
		instructions: "Choose how accurately each statement reflects you.",
		scale: {
			sd: "Strongly Disagree",
			d: "Disagree",
			n: "Neutral",
			a: "Agree",
			sa: "Strongly Agree"
		},
		notice: "Please respond to all statements to view your results.",
		notice1: "Please answer all questions to continue."
	},
	analyzing: {
		title: "Core Trait Analysis",
		desc: "Generating your comprehensive personality profile based on your unique responses..."
	},
	report: {
		title: "Discover Your Personality Report",
		subtitle: "Our analysis has successfully decoded your unique behavioral patterns. Gain the clarity you need to navigate your career and personal life with confidence.",
		features: {
			identity: {
				title: "Unveil Your Authentic Self",
				desc: "Dive deep into your core identity to uncover hidden potential and motivations."
			},
			strengths: {
				title: "The Anatomy of Your Strengths",
				desc: "Gain a clear understanding of your natural advantages and specific areas for growth."
			},
			relationships: {
				title: "Decode Your Social Dynamics",
				desc: "Enhance your social intelligence to build stronger, more meaningful connections."
			}
		},
		pricing: {
			access: "7-day full access",
			price: "HK$14.95",
			cta: "VIEW MY REPORT",
			trial: "7-day trial for $1.99, auto-renews at $27.88/mo. Cancel anytime.",
			ordered: "reports ordered!"
		},
		receive: {
			title: " Pathways to Personal Excellence",
			subtitle: "Access a science-based breakdown of your core traits and actionable strategies for personal growth.",
			card1: {
				title: "Comprehensive Personality Report ",
				desc: "An in-depth analysis that decodes your unique personality architecture and behavioral drivers."
			},
			card3: {
				title: "Personalized Course Recommendations ",
				desc: "Tailored educational strategies designed to bridge your skill gaps and accelerate growth."
			},
			card5: {
				title: "Skill Assessment Tests ",
				desc: "Targeted evaluations to quantify your natural advantages and professional core strengths."
			},
			card2: {
				title: "Practical Daily Challenges ",
				desc: "Actionable daily tasks focused on building resilient habits and sustainable development."
			},
			card4: {
				title: "Relationship Guide ",
				desc: "Actionable tips to improve your social interactions and build stronger professional connections."
			},
			card6: {
				title: "Certificates of Achievement ",
				desc: "Formal recognition of your profile insights and your commitment to personal excellence."
			}
		},
		trusted: {
			title: "Trusted by 20,000+ customers",
			subtitle: "Join thousands who have unlocked their potential through our expert-led personality framework. Real growth starts with deep self-awareness.",
			card_text: "I was skeptical, but the depth of this report is impressive. It’s a powerful tool for self-discovery that feels incredibly personal and surprisingly accurate.",
			card_text3: "I was skeptical, but the depth of this report is impressive. It’s a powerful tool for self-discovery that feels incredibly personal and surprisingly accurate.",
			card_text2: "Finally, a test that goes beyond surface-level traits. It explained my creative blocks perfectly and gave me practical steps to regain my focus and drive.",
			card_text1: "The insights into my subconscious motivations were eye-opening. It has completely changed how I handle workplace stress and helped me build much stronger team dynamics."
		},
		worldwide: {
			title: "Trusted by over 100 thousand people worldwide",
			subtitle: "Latest results",
			orders: {
				amelia: "Amelia just ordered. Personality type:",
				diego: "Diego just ordered. Personality type:",
				mia: "Mia just ordered. Personality type:"
			},
			types: {
				peacemaker: "Peacemaker",
				loyalist: "Loyalist"
			}
		},
		cta_full: {
			title: "Unlock Your Full Potential",
			access: "7-day full access",
			price: "HK$14.95",
			btn: "Get My Results",
			note: "7-day trial for $1.99, auto-renews at $27.88/mo. Cancel anytime.",
			list: {
				"1": "Unlock 50+ Premium Personality Assessments",
				"2": "Deep Evidence-Based Psychological Insights",
				"3": "Strategic Tools for Sustainable Personal Growth",
				"4": "Master Professional Dynamics and Career Goals"
			}
		}
	},
	finish: {
		title: "Congratulations!",
		subtitle: "Your personality profile is now complete.",
		button: "VIEW MY REPORT",
		reviewAnswers: "Review My Answers"
	},
	"以下没有更改": "",
	title: "Personality Test",
	description: "Start your personality assessment.",
	step: {
		title: "Test Steps",
		description: "Answer the questions step by step."
	},
	result: {
		title: "Test Results",
		description: "View your report and next actions."
	}
};
var orders$1 = {
	cancel: {
		subscription: {
			title: "Cancel My Subscription",
			description: " To initiate the cancellation process, please enter the email address associated with your account.",
			emailLabel: "Email",
			emailPlaceholder: "Email Address",
			emailError: "Please enter your email address to continue.",
			reasonDifficult: "The insights did not meet my personal expectations.",
			reasonTitle: "What’s the main reason for cancelling?",
			reasonMissing: "I have achieved my current self-discovery goals.",
			reasonTechnical: "The reporting depth was insufficient for my needs.",
			reasonSwitching: "I encountered technical issues during the assessment.",
			reasonTeam: "I am looking for a different psychological framework.",
			reasonBudget: "The subscription cost does not fit my budget.",
			reasonOther: "Other.",
			submitButton: "NEXT",
			contactSupport: "If you cannot recall the email address used for registration, please check your inbox for messages from \"PersonalityTest101\". Alternatively, feel free to contact our dedicated support team for <a href=\"mailto:support{'@'}personalitytest101.com\" style=\"text-decoration: underline;\">assistance</a>.",
			cancelSubscription: "You may also cancel your subscription by logging into your by logging into your account, navigating to the \"Membership\" tab, and selecting \"Cancel Subscription\".",
			confirmTitle: "Cancel Subscription",
			confirmDesc: "This action <strong>cannot be undone</strong>. All premium insights will be deleted.",
			confirmCancel: "Keep My Plan",
			confirmSubmit: "Cancel Anyway",
			successTitle: "Subscription Cancelled",
			successDesc: "Your subscription has been successfully cancelled.A confirmation email will be sent shortly.Premium access remains active until April 1, 2025 at 12:33 PM."
		}
	},
	purchaseComplete: {
		title: "Unlock Your Potential",
		description: "Your assessment results are prepared!",
		accessReport: "Open Report",
		downloadGuidebook: "Download Guidebook",
		accessNote: "Your guidebook is ready. Download it below!",
		btn2: "Download My Report",
		goHome: "Back to Home",
		btn1: "Open My Report"
	},
	create: {
		title: "Unlock All Reports",
		subtitle: "Discover your unique strengths and master your path to personal growth.",
		summary: {
			trial: "{day}-day trial",
			benefit1: "Personalized Career Matches",
			benefit2: "Deep Personality Insights",
			benefit3: "50+ Premium Assessments",
			terms: "Trial Details: {price1} for {day} days. Once the trial ends, a monthly subscription of {price2} will apply automatically. Cancel anytime: "
		},
		form: {
			email: "Email",
			emailPlaceholder: "Email address",
			name: "Cardholder name",
			namePlaceholder: "Full name on card",
			cardNumber: "Card number",
			cardNumberPlaceholder: "0000 0000 00000000",
			expires: "Expires",
			expiresPlaceholder: "MM / YY",
			cvv: "CVV",
			cvvPlaceholder: "CVC / CVV",
			zip: "Postal code",
			zipPlaceholder: "Zip / Postal code",
			orderId: "Order ID",
			emailError: "Please enter a valid email address",
			paymentError: "Payment failed. Please try again.",
			paymentSuccess: "Payment initiated successfully!",
			consentPart1: "By clicking \"Subscribe\", I electronically authorize PersonalityTest101 to charge my card per the Billing Terms, including automatic renewal, until cancellation. I agree to the",
			consentPart2: "and",
			terms: "Terms of Service",
			privacy: "Privacy Policy",
			subscribeBtn: "Subscribe Now · {price}",
			paypalBtn: "Pay with",
			gpayBtn: "Pay with"
		},
		trust: {
			us: "US-Based Company",
			noCharge: " No Hidden Fees",
			refund: "30-Day Money Back Guarantee",
			cancel: " Cancel Anytime"
		},
		testimonials: {
			title: "Trusted by 20,000+ customers",
			subtitle: "Join thousands who have unlocked their potential through our expert-led personality framework. Real growth starts with deep self-awareness.",
			reviews: {
				review1: {
					name: "Sarah Jenkins",
					role: "Marketing Manager",
					review: "A total game-changer for my self-awareness! The depth of the report was startlingly accurate, helping me understand my work habits in a way I never could before."
				},
				review2: {
					name: "David Chen",
					role: "Senior Developer",
					review: "I’ve taken many personality tests, but this is by far the most comprehensive. The actionable insights for personal growth provided me with a clear roadmap for my next career move."
				},
				review3: {
					name: "Elena Rodriguez",
					role: "HR Specialist",
					review: "Finally, a personality assessment that goes beyond surface-level traits. It gave me the vocabulary to explain my needs and improved my communication with my team overnight."
				},
				review4: {
					name: "James Thornton",
					role: "Creative Director",
					review: "The premium reports are worth every penny. Seeing my strengths and blind spots mapped out so clearly helped me lead with much more confidence and empathy."
				},
				review5: {
					name: "Lisa Nakamura",
					role: "Freelance Illustrator",
					review: "I was skeptical at first, but the results were spot-on. It’s not just a test; it’s a deep dive into what makes you tick. Highly recommended for anyone feeling stuck in their life."
				},
				review6: {
					name: "Mark Peterson",
					role: "Financial Analyst",
					review: "Fast, intuitive, and surprisingly profound. The career matching feature helped me realize why I was unhappy in my previous role and guided me toward a professional path that truly fits."
				},
				review7: {
					name: "Sophia Williams",
					role: "Content Strategist",
					review: "The most user-friendly platform I’ve used. The reports are beautifully designed and easy to digest, making complex psychological concepts accessible and immediately useful."
				},
				review8: {
					name: "Kevin Al-Sabah",
					role: "Project Manager",
					review: "A fascinating experience from start to finish. The insights into my personality type helped me manage my stress levels and find a much better work-life balance."
				},
				review9: {
					name: "Emma Johnson",
					role: "Marketing Consultant",
					review: "This personality test completely transformed my understanding of myself. The insights were so accurate that I immediately shared the results with my close friends and family."
				},
				review10: {
					name: "Michael Brown",
					role: "Psychology Student",
					review: "As someone who's always been interested in psychology, I was impressed by the scientific approach behind this test. The results provided me with actionable steps to improve my personal and professional relationships."
				},
				review11: {
					name: "Olivia Garcia",
					role: "Elementary School Teacher",
					review: "I took this test on a whim and was blown away by how much it resonated with me. It helped me understand why I react certain ways in different situations and gave me tools to manage my emotions better."
				},
				review12: {
					name: "Christopher Lee",
					role: "Sales Representative",
					review: "The career guidance section of the premium report was worth every penny. It confirmed some suspicions I had about my current job and pointed me in the direction of careers that would be a better fit for my personality."
				},
				review13: {
					name: "Jessica Taylor",
					role: "Project Coordinator",
					review: "I've recommended this test to all of my colleagues. The team-building insights alone were invaluable for our department, helping us understand each other's working styles and communication preferences."
				},
				review14: {
					name: "Daniel Martinez",
					role: "Business Analyst",
					review: "What sets this test apart from others I've taken is the depth of analysis. It doesn't just tell you what your personality type is; it explains why you behave the way you do and how to leverage your strengths."
				}
			}
		}
	}
};
var pricing$1 = {
	subtitle: "Leverage psychometric data to navigate your career, enhance relationships, and master your personal growth strategy.",
	title: "Empower Your Future with Expert Insights",
	includedFeatures: "INCLUDED FEATURES",
	badge: "POPULAR",
	plans: {
		weekly: {
			button: "Begin Trial"
		},
		monthly: {
			button: "Start Monthly Plan"
		},
		yearly: {
			button: "Get Yearly Access"
		}
	},
	features: {
		priorityAccess: "Priority Access to New Assessments ",
		archetypeAnalysis: "Comprehensive Archetype Analysis ",
		careerMapping: "Career Alignment Mapping ",
		interpersonalGuide: "Interpersonal Dynamics Guide ",
		aiGrowthCoach: "Personalized AI Growth Coach ",
		selfEsteemBlueprint: "Self-Esteem Mastery Blueprint "
	}
};
var home$1 = {
	title: "Uncover your authentic personality",
	description: "Learn what makes you unique with our accurate personality assessment",
	cta: "Take the Test",
	accuracy: {
		title: "Curious how accurate we are about you?",
		description: "Connect to professional networks, gain valuable insights, and access \n resources to move toward your ideal career."
	},
	stats: {
		testsToday: "Daily Discoveries",
		testsUS: "Global Community",
		totalTests: "Insights Delivered",
		accurateRate: "Scientifically Validated Accuracy",
		value1: "241K+",
		value2: "172M+",
		value3: "1460M+",
		value4: "91.2%"
	},
	why: {
		title: "Why Take the Test?",
		desc: "Gain guidance from expert mentors who offer fresh perspectives, innovative insights, and proven strategies to help you understand yourself better.",
		main: {
			title: "Master Your Inner Self",
			desc: "Gain deep psychological insights through data-driven analysis, with personalized guidance to master your core traits and behaviors."
		},
		small1: {
			title: "Smarter Life Choices",
			desc: "Leverage psychological clarity to navigate complex choices with confidence and reduce cognitive bias."
		},
		small2: {
			title: "Healthier Connections",
			desc: "Decode your social dynamics to foster deeper empathy and build more authentic interpersonal bonds."
		},
		small3: {
			title: "Professional Alignment",
			desc: "Align your career path with your natural strengths to achieve sustainable success and genuine fulfillment."
		},
		"desc-mobile": "Gain guidance from expert mentors who offer fresh perspectives, innovative insights, and proven strategies to help you understand yourself better."
	},
	how: {
		title: "How Our Analysis Works",
		desc: "From honest answers to profound self-discovery in minutes.",
		step1: {
			title: "Prepare Your Mind",
			desc: "Take a deep breath and create a calm, focused space — the best insights come when you're relaxed and attentive."
		},
		step2: {
			title: "Explore Your Personality",
			desc: "Dive into the different facets of your character, from strengths to hidden tendencies, and see how they shape your behavior."
		},
		step3: {
			title: "Gain Personal Insights",
			desc: "Receive detailed guidance and actionable suggestions to better understand yourself and grow personally and professionally."
		}
	},
	receive: {
		title: "What You'll Gain",
		desc: "Participate at your own pace, in a supportive and positive environment designed to deliver genuine self-insight and meaningful outcomes.",
		card1: {
			title: "Comprehensive Personality Report",
			desc: "Understand your strengths, preferences, and potential blind spots."
		},
		card2: {
			title: "Tailored Growth Recommendations",
			desc: "Get personalized suggestions to support your personal development and decisions."
		},
		card3: {
			title: "Skill & Behavior Insights",
			desc: "Explore your tendencies and track your growth over time."
		},
		card4: {
			title: "Practical Self-Discovery Exercises",
			desc: "Apply insights through small, actionable exercises in daily life."
		},
		card5: {
			title: "Curated Knowledge Library",
			desc: "Access resources to deepen self-understanding and ongoing growth."
		},
		card6: {
			title: "Certificates of Self-Awareness",
			desc: "Celebrate your self-discovery journey with certificates of achievement."
		}
	},
	testimonials: {
		title: "Trusted by 20,000+ customers",
		subtitle: "Be always were in form of volunteers range time is mediatingappositive the in our affidavit how solitary saw more in his not"
	},
	faq: {
		title: "Frequently Asked Questions",
		description: "Frequently Asked Questions offers a quick answers to common queries, guiding users  through features and functionalities efficiently.",
		"description-mobile": "Frequently Asked Questions offers quick answers to common queries, guiding users through features and functionalities effortlessly."
	},
	curious: {
		buttonText: "Take the Test"
	}
};
var testDetail = {
	welcome: "Welcome, {name}!",
	type: "Type",
	allAbout: "All About You",
	typeName: "Enthusiast",
	readMore: "Read more",
	aboutDesc: "Type 7 in the Enneagram is often called the Enthusiast: they are energetic, spontaneous and optimistic. Their core motivation is to avoid fear, pain, or discomfort and to maintain a pursuit of new experiences.",
	totalScore: "Total score",
	subtypesIntro: "The Enneagram outlines three subtypes for Type 7, each highlighting different expressions of their core characteristics:",
	tab: {
		core: "Core characteristics",
		motivation: "Motivations & Fears",
		relationships: "Relationships",
		work: "Work",
		stress: "Stress & Relaxation",
		compatibility: "Compatibility"
	},
	core: {
		title: "Core Characteristics of The Enthusiast",
		cardTitle: "Optimism and Positivity",
		cardDesc: "They tend to stay optimistic, seek pleasure, and avoid discomfort, driven by possibilities and new experiences."
	}
};
var personalityDetail = {
	subtypes: {
		title: "Enthusiast Subtypes",
		subtitle: "Each subtype emphasizes different focuses and behavioral patterns:",
		sp: "Self-Preservation (SP) Type 7",
		spDesc: "Safety and resources oriented; plans, reserves, and self-soothes to reduce discomfort.",
		social: "Social (SO) Type 7",
		socialDesc: "Group and belonging focused; seeks experiences and connection, good at organizing and participating.",
		oneToOne: "One-to-One (SX) Type 7",
		oneToOneDesc: "Intense experiences and close bonds; pursues passion and deeper connection.",
		cta: "Take a course"
	},
	conclusion: {
		title: "Conclusion",
		p1: "Based on your core characteristics and motivations, we recommend exploring and practicing in a gentle, structured way to build stable rhythms and clear priorities.",
		p2: "In relationships and work, leverage your creativity and optimism while introducing appropriate constraints and commitments to improve execution and reflection.",
		p3: "Start with the growth path below to gradually strengthen discomfort tolerance, mindfulness practice, and commitment—supporting long-term, sustainable growth."
	},
	growth: {
		title: "Growth Path for The Enthusiast",
		items: {
			i1: {
				title: "Confronting Fear of Discomfort",
				body: "Progress involves gradually facing discomfort and negative experiences—such as boredom or sadness—without immediately seeking distraction or escape. Embracing the full spectrum builds resilience and emotional maturity."
			},
			i2: {
				title: "Practicing Mindfulness and Presence",
				body: "Cultivate present-moment awareness and self-connection. Avoid over-chasing novelty; move at a steadier pace and find deeper satisfaction in more meaningful experiences."
			},
			i3: {
				title: "Embracing Commitment and Follow-Through",
				body: "Learn to prioritize and complete tasks, resisting the pull of constant new opportunities. With focus and discipline, turn visions into reality and create meaningful impact in life and career."
			}
		},
		ctaCourses: "View courses",
		ctaTests: "View tests"
	},
	faq: {
		title: "Frequently Asked Questions",
		description: "Quick answers to common queries, guiding you through features and functionalities.",
		q1: "Can I track my assignments and grades?",
		a1: "Yes. The platform provides a Gradebook where students can view grades, monitor feedback on assignments, and check due dates. Instructors can post grades and comments for each submission.",
		q2: "Does the LMS support video lessons and live classes?",
		a2: "Yes. Courses can use recorded videos and live sessions depending on the instructor and course design.",
		q3: "How can I communicate with my instructor?",
		a3: "You can use in-course messaging, comments, or designated communication channels to contact instructors.",
		q4: "What support is available for students and instructors?",
		a4: "Support includes progress tracking, assessment reports, course management tools, and grading and feedback for instructors.",
		q5: "Are there interactive features for students?",
		a5: "Yes. Features include quizzes, discussions, assignments, and feedback to enhance the learning experience."
	}
};
var routeGuide$1 = {
	title: "Route Guide",
	intro: "All available routes in the system are listed below. Click to navigate.",
	stats: "There are {count} available routes in the system",
	pathLabel: "Path",
	visit: "Visit",
	empty: "No available routes found",
	back: "Back to Home"
};
var tests$1 = {
	filters: {
		all: "All Tests",
		soft: "Soft Skills",
		hard: "Hard Skills"
	},
	badges: {
		soft: "Soft Skills",
		hard: "Hard Skills"
	},
	questions: "{count} questions",
	hero: {
		title: "Financial Analysis",
		objective: "Objective: To assess proficiency in a specific hard skill through multiple-choice questions designed to evaluate knowledge, application, and problem-solving."
	},
	cards: {
		operations: {
			title: "Operations Management",
			desc: "Objective: Assess proficiency in a specific hard skill via multiple-choice questions evaluating knowledge, application, and problem-solving."
		},
		business: {
			title: "Business Analysis",
			desc: "Your score: 25 out of 40 points."
		}
	},
	completed: "Completed",
	cta: {
		startNow: "Start now",
		readMore: "Read more",
		viewResults: "View results",
		tryAgain: "Try again",
		loadMore: "Load more tests"
	}
};
var testStart = {
	title: "Anger Management",
	format: {
		title: "Format:",
		body: "The test consists of 10 multiple-choice questions. Each question has four answer choices, reflecting different responses to anger-provoking scenarios."
	},
	scoring: {
		title: "Scoring:",
		body: "Each answer is assigned a point value. The total score is calculated by summing the points from all answers."
	},
	cta: {
		getStarted: "Get Started"
	},
	disclaimer: "Taking our test should not be viewed as a comprehensive or precise evaluation of your personality and mental well-being."
};
var testEnd = {
	score: "<strong style='font-size: 24px;'>{value}/{total}</strong> points",
	title: "Developing Financial Analysis Skills",
	description: "Your score suggests that you are in the early stages of developing your financial analysis skills. You may find basic concepts and calculations challenging and might not be familiar with many of the tools and techniques used in financial analysis.",
	areasTitle: "Areas for Improvement:",
	areas: {
		format: {
			title: "Format",
			body: "The test consists of 10 multiple-choice questions with four answer choices, reflecting different responses."
		},
		financial: {
			title: "Financial Statements",
			body: "Improve understanding of the balance sheet, income statement, and cash flow statement."
		},
		ratio: {
			title: "Ratio Analysis",
			body: "Get familiar with basic financial ratios and their implications for a company’s financial health."
		},
		investment: {
			title: "Investment Appraisal",
			body: "Start with techniques like NPV and ROE to understand how to evaluate opportunities."
		}
	},
	ctaPrimary: "Take another test",
	ctaSecondary: "View Courses",
	disclaimer: "Taking our test should not be viewed as a comprehensive or precise evaluation of your personality and mental well-being."
};
var userCourseChapters = {
	title: "People Leadership vs. Management",
	description: "Leadership and management are two distinctive and complementary systems of actions in the business environment. Both are necessary for success in an increasingly complex and volatile business environment.",
	coverQuestion: "What will we cover?",
	cta: "Start Learning"
};
var userCourseLearn = {
	lessonCount: "Lesson {current} of {total}",
	title: "Communication Skills for Leaders",
	objective: {
		title: "Objective",
		body: "By the end of this lesson, learners will understand the vital role of communication in leadership. They will explore key communication skills including active listening, effective speaking, and providing constructive feedback. Additionally, learners will learn strategies to improve their communication skills in various leadership contexts."
	},
	intro: {
		title: "Introduction",
		body: "Effective communication is the cornerstone of successful leadership. It involves not just the transmission of information but also ensuring that the intended message is received and understood. For leaders, mastering communication skills is essential for inspiring and motivating teams, setting clear expectations, and building trust."
	},
	cta: "Next"
};
var userCourseLesson = {
	lessonCount: "Lesson {current} of {total}",
	title: "Key Communication Skills for Leaders",
	sections: {
		activeListening: {
			title: "Active Listening",
			descriptionTitle: "Description",
			descriptionBody: "Active listening involves fully concentrating, understanding, responding, and then remembering what is being said.",
			applicationTitle: "Application in Leadership",
			applicationBody: "Leaders who are active listeners can better understand team needs, anticipate problems, and build stronger relationships."
		},
		effectiveSpeaking: {
			title: "Effective Speaking"
		},
		takeaways: {
			title: "Key Takeaways",
			i1: "Change management is crucial for the successful implementation of organizational changes.",
			i2: "The change management process involves preparing for change, managing the change, and reinforcing the change to ensure it is embedded in the organization.",
			i3: "Effective leaders use clear communication, stakeholder engagement, and support mechanisms to facilitate change and overcome resistance."
		}
	},
	ctaPrimary: "Back",
	ctaSecondary: "Next"
};
var userCourseLessonComplete = {
	title: "Congratulations!",
	desc: "You have successfully completed lesson {current} of {courseName} course.",
	cta: "Next Lesson",
	toDashboard: "Go to Dashboard"
};
var userCourseChapterComplete = {
	title: "Congratulations!",
	desc1: "You have successfully completed all lessons of our {courseName} course.",
	desc2: "Time to see what you've learned and get your certificate.",
	format: {
		title: "Format",
		body: "The test consists of 10 multiple-choice questions. Each question has four answer choices, reflecting different attitudes and behaviors related to time management."
	},
	scoring: {
		title: "Scoring",
		body: "Each answer is assigned a point value. The total score is calculated by summing the points from all answers."
	},
	cta: "Get Certified",
	later: "I'll do it later"
};
var userCourseTest = {
	questionCount: "Question {current} of {total}",
	question: "During the 'Storming' stage of team development, a leader should:",
	o1: "Allow the team to resolve their conflicts without intervening.",
	o2: "Facilitate open communication and mediate conflicts.",
	o3: "Focus solely on task execution to avoid delays.",
	o4: "Establish strict rules to control team dynamics.",
	next: "Next",
	finish: "Finish",
	cta: "Submit",
	pleaseSelect: "Please select an answer"
};
var userCourseTestComplete = {
	scoreLabel: "{score}/{total}",
	description: "Great job! You’ve completed the test. Review your score and continue learning.",
	cta: "Try again"
};
var ebooks$1 = {
	myTitle: "My e-books",
	otherTitle: "Other e-books",
	primary: {
		title: "Self-Esteem Guide: Build a Stronger You!",
		desc: "This exclusive package is designed to empower you to recognize your worth, navigate life's challenges with confidence, and foster healthy relationships.",
		download: "Download",
		readOnline: "Read Online"
	},
	cardTitle: "Personal Growth Guidance: Unlock Your Best Self Today!",
	sale: "SALE",
	oneTime: "One-time payment",
	buyNow: "Buy Now",
	readMore: "Read More"
};
var ebookDetail = {
	hero: {
		title: "What Is Self-Esteem?",
		subtitle: "Understanding its importance for Well-being"
	},
	title: "Top Marketing Skills to Boost Your Brand Engagement and Reach",
	intro: "In today's competitive digital landscape, building a strong brand presence and engaging effectively with your audience is more important than ever. With countless brands vying for attention, mastering key marketing skills can make the difference between a thriving brand and one that goes unnoticed. This blog explores the essential marketing skills that can elevate your brand’s engagement and broaden its reach.",
	sections: {
		contentCreation: {
			title: "Content Creation and Storytelling",
			body: "Creating valuable content is at the heart of effective marketing. Your brand’s content should not only inform but also inspire and connect emotionally with your audience. Whether through blog posts, videos, or social media updates, a good storyteller can transform a simple message into a memorable narrative that resonates."
		},
		keyTakeaway: {
			title: "Key Takeaway:",
			body: "Invest time in learning to craft compelling stories and produce high-quality, relevant content. It will help your brand stand out and build a loyal audience."
		},
		social: {
			title: "Social Media Management",
			body: "With billions of people on social media platforms, these channels are invaluable for brand engagement. Knowing how to leverage social media platforms effectively can help you reach new audiences, foster community, and create shareable content. Key skills include scheduling, engaging with followers, and staying on top of platform trends and algorithms."
		},
		about: {
			title: "About the Course",
			body: "This course offers a comprehensive introduction to the core building blocks of web development: HTML, CSS, and JavaScript. You'll start from the basics of structuring web pages, styling them, and adding interactivity. This hands-on approach is designed for beginners and is ideal for those looking to build a strong foundation in front-end web development, whether you’re aspiring to become a professional developer or want to create polished personal websites and projects."
		},
		analytics: {
			title: "Data Analytics and Insights",
			body: "Understanding analytics is crucial for measuring the success of your marketing efforts. Platforms like Google Analytics and social media insights help you track website traffic, user behavior, engagement rates, and more. Analyzing this data enables you to make data-driven decisions that refine your marketing strategies and enhance engagement."
		},
		video: {
			title: "Video Marketing",
			body: "Video content has become an essential tool for engaging audiences. It captures attention faster than text, allowing brands to communicate complex information in an easy-to-digest format. Video marketing skills include scriptwriting, editing, and understanding video trends that resonate with your audience."
		},
		copywriting: {
			title: "Copywriting and Persuasive Communication",
			body: "Copywriting is the art of using words to inspire action. From website copy to social media captions, well-crafted copy can attract readers, encourage readers, and drive conversions. Learn to write with your audience in mind and focus on clear, persuasive messaging."
		}
	},
	learn: {
		title: "What You'll Learn",
		i1: "HTML Fundamentals: Structure and organize web pages using HTML tags, attributes, and elements.",
		i2: "CSS Essentials: Style and layout web pages with CSS, including typography, colors, flexbox, and grid.",
		i3: "JavaScript Basics: Add interactivity with JavaScript fundamentals, including variables, functions, loops, and DOM manipulation.",
		i4: "Responsive Design: Build layouts that adapt to different screen sizes and devices.",
		i5: "Project-Based Learning: Create real-world projects to showcase your skills and deepen your understanding of web development."
	},
	require: {
		title: "Requirements",
		i1: "Computer & Internet Access: A laptop or desktop with a stable internet connection.",
		i2: "Code Editor: Install a code editor like Visual Studio Code (recommended) or any editor of your choice.",
		i3: "Basic Computer Skills: Familiarity with using a computer, installing software, and navigating the internet.",
		i4: "No Prior Coding Knowledge Required: This course is designed for absolute beginners."
	},
	cta: {
		download: "Download",
		close: "Close"
	}
};
var profile$1 = {
	welcome: "Welcome, {name}!",
	aboutTitle: "All About Your",
	type: "Type",
	typeName: "Enthusiast",
	aboutDesc: "Type 7s on the Enneagram are often referred to as The Enthusiasts: energetic, spontaneous, and optimistic. Their core drive is to avoid fear, pain, or discomfort while pursuing new experiences.",
	intro: "Type 7 in the Enneagram is often called the Enthusiast or Hedonist. They are vibrant, curious, and optimistic individuals always seeking new experiences and opportunities.",
	optimisticDesc: "Type 7s are known for their optimistic outlook on life, seeing the silver lining even in difficult situations. They approach challenges with enthusiasm and curiosity, believing there's always a positive angle.",
	detailedDesc: "Type 7 in the Enneagram is often called the Enthusiast or Hedonist. They are vibrant, curious, and optimistic individuals always seeking new experiences and opportunities. Type 7s fear being limited or missing out on anything life has to offer, so they tend to keep multiple options and possibilities open. They are creative, able to see connections between different things and often come up with innovative ideas. While Type 7s may appear carefree on the surface, deep down they fear pain and negative emotions, so they avoid these feelings by staying busy and pursuing pleasure.",
	totalScore: "Total score",
	dailyTrivia: "Daily trivia",
	triviaQuestion: "What is an essential trait for problem-solving?",
	viewResults: "Answer & view results",
	dailyStreak: "Daily streak",
	begin: "Days in a row Begin your transformation!",
	continueLearning: "Continue Learning",
	continueCourse: {
		label: "Continue your course",
		title: "Financial Management",
		desc: "Financial management is a critical aspect of organizational success, involving the effective management of financial resources to achieve organizational goals and maximize shareholder value.",
		cta: "Continue course"
	},
	progress: {
		title: "Your progress",
		tests: "Completed tests",
		courses: "Finished course",
		challenges: "Completed challenge",
		count: "{answered}/{total}",
		step: "Step {current} of {total}"
	},
	takeAnother: "Take another test",
	tag: {
		hard: "Hard Skills"
	},
	questions: "questions",
	completed: "Completed",
	tryAgain: "Try again",
	lessons: "lessons",
	testDetail: "Read more",
	readMore: "Read more"
};
var courses$1 = {
	title: "Courses",
	description: "Browse expert courses across fields."
};
var mentors$1 = {
	title: "Mentors",
	description: "Meet experienced mentors and instructors."
};
var course = {
	recommendedForYou: "Recommended for you",
	lessons: "lessons",
	certificate: "Certificate",
	allCourses: "All courses",
	cta: {
		start: "Start"
	}
};
var blog$1 = {
	title: "Blog",
	description: "Read team articles and latest updates.",
	hero: {
		title: "Empower Your Journey \n with Expert Career Insights"
	},
	exploreTitle: "Explore All Insights",
	breadcrumb: {
		list: "Home / Blog"
	},
	loadMore: "View More Blogs",
	sidebar: {
		categories: "Categories",
		recent: "Recent Blogs",
		tags: "Tags",
		follow: "Follow us:"
	},
	detail: {
		breadcrumb: "Home / Blog / Blog Details",
		sections: {
			keyTakeaway: "Key Takeaway",
			contentCreation: {
				title: "Content Creation and Storytelling",
				body: "Creating valuable content is at the heart of effective marketing. A strong storyteller can turn a simple message into a memorable narrative that resonates with audiences."
			},
			socialMedia: {
				title: "Social Media Management",
				body: "Leverage social platforms to reach new audiences, foster community, and create shareable content. Key skills include scheduling, engaging with followers, and staying on top of trends and algorithms."
			},
			analytics: {
				title: "Data Analytics and Insights",
				body: "Analytics help measure marketing success. Tools like Google Analytics and social platform insights track traffic, behavior, engagement, and more to inform data-driven decisions."
			},
			video: {
				title: "Video Marketing",
				body: "Video captures attention quickly and communicates complex information effectively. Skills include scripting, editing, and understanding video trends that resonate with audiences."
			},
			copywriting: {
				title: "Copywriting and Persuasive Communication",
				body: "Compelling copy inspires action. Clear messages, strong structure, and audience-focused tone turn ideas into outcomes."
			}
		}
	}
};
var account$1 = {
	settings: {
		title: "Account Settings",
		profile: {
			title: "Profile Information",
			namePlaceholder: "First and last name",
			emailPlaceholder: "Enter your email address",
			name: "Name",
			email: "Email Address"
		},
		password: {
			title: "Change Password",
			current: "Current password",
			"new": "New password",
			repeat: "Confirm new password"
		},
		language: {
			title: "Language Preferences",
			placeholder: "Select your preferred language"
		},
		"delete": {
			title: "Delete My Account",
			action: "Delete My Account",
			tips: "This action is permanent and cannot be undone. All your data and test results will be permanently removed."
		}
	}
};
var legal$1 = {
	privacy: {
		title: "Privacy Policy",
		description: "We value your privacy. Here's how we collect, use, and protect information.",
		nav: {
			privacyPolicy: "Privacy Policy",
			informationWeCollect: "Information We Collect",
			howWeUseYourInformation: "How We Use Your Information",
			anonymizationOfTestData: "Anonymization of Test Data",
			dataSharingAndDisclosure: "Data Sharing and Disclosure",
			cookiesAndTrackingTechnologies: "Cookies and Tracking Technologies",
			changesToThisPrivacyPolicy: "Changes to This Privacy Policy",
			informationalPurposeDisclaimer: "Informational Purpose Disclaimer",
			contactUs: "Contact Us"
		},
		sections: {
			privacyPolicy: {
				title: "Privacy Policy",
				subtitle: "Last Updated: November 25, 2024",
				content: "<p>We respect your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, store, and protect your information when you use our website and personality testing services.</p><p>By accessing or using our services, you agree to the practices described in this Privacy Policy.</p>"
			},
			informationWeCollect: {
				title: "Information We Collect",
				content: "<p>We may collect the following types of information when you use our services:</p><ul style=\"padding-left: 20px;list-style: disc;\"><li><strong>Personal Information:</strong> Such as an email address or username if you voluntarily provide it.</li><li><strong>Assessment Data:</strong> Responses, results, and interactions related to personality tests, quizzes, or questionnaires.</li><li><strong>Usage Information:</strong> Pages visited, features used, test completion status, and interaction behavior.</li><li><strong>Technical Information:</strong> IP address, browser type, device type, operating system, and language preferences.</li></ul><p>We collect only information necessary to provide and improve our services.</p>"
			},
			howWeUseYourInformation: {
				title: "How We Use Your Information",
				content: "<p>We use the collected information to:</p><ul style=\"padding-left: 20px;list-style: disc;\"><li>Provide, operate, and maintain our personality testing services</li><li>Generate and display test results and personalized insights</li><li>Improve website performance, content, and overall user experience</li><li>Communicate service-related updates or respond to inquiries</li><li>Detect and prevent fraud, abuse, or unauthorized access</li><li>Comply with applicable legal and regulatory requirements</li></ul>"
			},
			anonymizationOfTestData: {
				title: "Anonymization of Test Data",
				content: "<p>To enhance user privacy, personality test responses and results may be processed in an aggregated or anonymized manner. This means such data cannot be used to directly identify individual users. Anonymized data may be used for statistical analysis, service improvement, and research purposes.</p>"
			},
			dataSharingAndDisclosure: {
				title: "Data Sharing and Disclosure",
				content: "<p>We do not sell, rent, or trade your personal information.</p><p>We may share your information only in the following circumstances:</p><ul style=\"padding-left: 20px;list-style: disc;\"><li>With trusted third-party service providers who assist in website hosting, analytics, customer support, or payment processing</li><li>When required by law, regulation, or legal process</li><li>To protect the rights, safety, or security of users or the platform</li><li>With your explicit consent</li></ul><p>All third parties are required to handle data securely and only for authorized purposes.</p>"
			},
			cookiesAndTrackingTechnologies: {
				title: "Cookies and Tracking Technologies",
				content: "<p>We use cookies and similar tracking technologies to:</p><ul style=\"padding-left: 20px;list-style: disc;\"><li>Remember user preferences and settings</li><li>Analyze website usage and traffic</li><li>Improve functionality and user experience</li></ul><p>You can manage or disable cookies through your browser settings. Please note that disabling cookies may limit certain features of the website.</p>"
			},
			changesToThisPrivacyPolicy: {
				title: "Changes to This Privacy Policy",
				content: "<p>We may update this Privacy Policy from time to time to reflect changes in our practices or legal requirements. Any updates will be posted on this page with a revised \"Last Updated\" date. Continued use of the website after such changes constitutes acceptance of the updated policy.</p>"
			},
			informationalPurposeDisclaimer: {
				title: "Informational Purpose Disclaimer",
				content: "<p>All personality test results and related content provided on this website are for <strong>informational and educational purposes only</strong>. They are not intended to diagnose, treat, or replace professional psychological, medical, or mental health advice. Users are encouraged to seek qualified professionals for personalized guidance when appropriate.</p>"
			},
			contactUs: {
				title: "Contact Us",
				content: "<p>If you have any questions, concerns, or requests regarding this Privacy Policy or how we handle your information, please contact us at:</p><p><strong>Email:</strong> <a href=\"mailto:support{'@'}personalitytest101.com\" style=\"text-decoration: underline;\">support{'@'}personalitytest101.com</a></p><p>We will make reasonable efforts to respond to your inquiry in a timely manner.</p>"
			}
		}
	},
	refund: {
		title: "Refund and Cancellation Policy",
		description: "Our refund policy is clear and fair. Learn about refund eligibility and cancellation rights.",
		nav: {
			refundPolicy: "Refund and Cancellation Policy",
			subscriptionPlans: "Subscription Plans & Refunds",
			refundConditions: "When Refunds Are Possible",
			cancellationRights: "Subscription Cancellation & Right to Cancel",
			refundRequest: "How to Request a Refund",
			friendlyNotes: "A Few Friendly Notes",
			whySimple: "Why We Keep It Simple"
		},
		sections: {
			refundPolicy: {
				title: "Refund and Cancellation Policy",
				subtitle: "Last Updated: February 2, 2026",
				content: "<p>We want every subscription to bring you meaningful insights into your personality. While our tests are designed to provide valuable results, we understand that sometimes things don't go as expected. Here's our refund and cancellation policy — clear, fair, and user-friendly.</p>"
			},
			subscriptionPlans: {
				title: "1. Subscription Plans & Refunds",
				content: "<table style=\"width: 100%; border-collapse: collapse; margin-bottom: 20px; border: 1px solid #000;\"><thead><tr style=\"background-color: #fff;\"><th style=\"padding: 12px; text-align: left; border: 1px solid #000;\">Plan</th><th style=\"padding: 12px; text-align: left; border: 1px solid #000;\">Refund Window</th><th style=\"padding: 12px; text-align: left; border: 1px solid #000;\">Refund Amount</th></tr></thead><tbody><tr><td style=\"padding: 12px; border: 1px solid #000;\"><strong>7-Day Trial</strong></td><td style=\"padding: 12px; border: 1px solid #000;\">Not refundable</td><td style=\"padding: 12px; border: 1px solid #000;\">N/A</td></tr><tr><td style=\"padding: 12px; border: 1px solid #000;\"><strong>Monthly Subscription</strong></td><td style=\"padding: 12px; border: 1px solid #000;\">Within 14 days of purchase</td><td style=\"padding: 12px; border: 1px solid #000;\">50% of the subscription fee</td></tr><tr><td style=\"padding: 12px; border: 1px solid #000;\"><strong>Annual Subscription</strong></td><td style=\"padding: 12px; border: 1px solid #000;\">Within 14 days of purchase</td><td style=\"padding: 12px; border: 1px solid #000;\">50% of the subscription fee</td></tr></tbody></table><p><strong>💡 Tip:</strong> Personalized reports are considered delivered once accessed, so full refunds are not available.</p>"
			},
			refundConditions: {
				title: "2. When Refunds Are Possible",
				content: "<p>Refunds will not be granted for:</p><ul style=\"padding-left: 20px;list-style: disc;\"><li>Changing your mind or personal preference</li><li>Not liking your report results</li><li>Waiting time expectations</li><li>Personalized reports that have already been accessed</li></ul>"
			},
			cancellationRights: {
				title: "3. Subscription Cancellation & Right to Cancel",
				content: "<p>You may cancel your subscription at any time to stop future payments. After cancellation, you can continue to use your subscription until the end of your current billing period.</p><p>In addition, your statutory rights under applicable consumer laws remain valid:</p><ul style=\"padding-left: 20px;list-style: disc;\"><li>You have the right to cancel a contract for digital content within 14 days without giving any reason.</li><li>If you start accessing or downloading your digital content during this period, you acknowledge that your right to cancel will be lost once the content is accessed.</li><li>The 14-day period begins on the day your subscription is confirmed via email.</li><li>To exercise this right, notify us via email: support{'@'}personalitytest101.com with a clear statement that you wish to cancel.</li><li>To meet the deadline, it is sufficient to send your cancellation notice before the 14-day period ends.</li></ul>"
			},
			refundRequest: {
				title: "4. How to Request a Refund",
				content: "<p>To request a refund within our policy:</p><ul style=\"padding-left: 20px;list-style: disc;\"><li>Email: support{'@'}personalitytest101.com</li><li>Include your account email, order details, and reason for the refund.</li></ul><p>Refunds are processed to the original payment method, usually within 30 business days after approval.</p>"
			},
			friendlyNotes: {
				title: "5. A Few Friendly Notes",
				content: "<ul style=\"padding-left: 20px;list-style: disc;\"><li>Personalized reports are created just for you and cannot be returned.</li><li>Refunds apply only to the most recent payment.</li><li>Each request is reviewed personally to ensure fairness and transparency.</li></ul><p>Our goal is that every test brings value and helps you understand yourself better.</p>"
			},
			whySimple: {
				title: "Why We Keep It Simple",
				content: "<p>We know your time and trust are valuable. By providing clear refund windows, explaining partial refunds, and including your legal cancellation rights, we hope you feel confident subscribing, knowing that:</p><ol style=\"padding-left: 20px;list-style: decimal;\"><li>We deliver meaningful, personalized reports.</li><li>You have a clear path if technical problems occur.</li><li>You're supported every step of the way.</li></ol>"
			}
		}
	},
	terms: {
		title: "Terms of Use & Purchase",
		description: "By using this service, you agree to the following terms and conditions.",
		nav: {
			termsOfUse: "Terms of Use & Purchase",
			introduction: "1. Introduction",
			registration: "2. Registration",
			personalityTest: "3. Personality Test & AI Tools",
			purchase: "4. Purchase of Digital Content & Subscriptions",
			refunds: "5. Refunds & Cancellation",
			license: "6. License to Use Website & Products",
			acceptableUse: "7. Acceptable Use",
			userContent: "8. User Generated Content",
			noticeTakedown: "9. Notice and Takedown",
			unsolicitedIdeas: "10. Unsolicited Idea Submissions",
			warranties: "11. Warranties & Disclaimers",
			liability: "12. Liability Limitations",
			indemnity: "13. Indemnity",
			breaches: "14. Breaches & Enforcement",
			changes: "15. Changes & Variation",
			entireAgreement: "16. Entire Agreement",
			contact: "17. Contact"
		},
		sections: {
			termsOfUse: {
				title: "Terms of Use & Purchase",
				subtitle: "Last Updated: February 2, 2026",
				content: "<p>Welcome to PersonalityTest101.com. These Terms of Use & Purchase govern your access to our website and your purchase of digital content, subscriptions, and services (collectively, \"Products\"). By using our website, you agree to these terms in full. If you do not agree, please do not use the website or purchase any Products.</p>"
			},
			introduction: {
				title: "1. Introduction",
				content: "<ul style=\"padding-left: 20px;list-style: disc;\"><li>Our Products are designed for information and entertainment purposes only. They are not medical, psychological, or professional advice.</li><li>Personalized reports and AI outputs are for personal use only, not for assessing others or business/recruitment purposes.</li><li>Users must be 16 years or older (or the legal age of consent in their country).</li><li>AI Mentor (Elina) outputs are informational only, and you should avoid sharing sensitive personal data.</li><li>The English version of the website is the official version. Other language versions are provided for convenience.</li><li>Use of cookies and personal data is governed by our Privacy Policy.</li></ul>"
			},
			registration: {
				title: "2. Registration",
				content: "<ul style=\"padding-left: 20px;list-style: disc;\"><li>Some website areas are free to access. Certain Products require registration.</li><li>You must provide accurate and up-to-date information.</li><li>Keep your password confidential and report any suspected account breaches to support{'@'}personalitytest101.com.</li><li>Only one account per user is allowed. We reserve the right to suspend or cancel accounts that violate these terms.</li></ul>"
			},
			personalityTest: {
				title: "3. Personality Test & AI Tools",
				content: "<ul style=\"padding-left: 20px;list-style: disc;\"><li>Free Personality Test results assign one of 16 personality types and two variants.</li><li>Premium Profiles and Specialized Tests are paid Products.</li><li>AI tools (e.g., Elina) supplement guidance but do not constitute professional advice.</li></ul>"
			},
			purchase: {
				title: "4. Purchase of Digital Content & Subscriptions",
				content: "<ul style=\"padding-left: 20px;list-style: disc;\"><li>Products are licensed, not sold, and remain our property.</li><li>Payment is authorized at purchase. Your order is confirmed upon successful payment.</li><li>Prices are in USD, include VAT where applicable, and are subject to change.</li><li>E-books require a PDF reader. Digital rights management (DRM) must not be removed.</li></ul>"
			},
			refunds: {
				title: "5. Refunds & Cancellation",
				content: "<p>Refund eligibility depends on the Product type:</p><ul style=\"padding-left: 20px;list-style: disc;\"><li>7-Day Trial: Non-refundable</li><li>Monthly Subscription: Refundable within 7 days at 50% of fee</li><li>Annual Subscription: Refundable within 14 days at 50% of fee</li></ul><p>Refunds are only for technical issues, not personal preference or report dissatisfaction.</p><p>Statutory rights under consumer law remain valid: You can cancel digital content contracts within 14 days, but once accessed, this right is lost.</p><p>Refund requests must be sent to support{'@'}personalitytest101.com.</p>"
			},
			license: {
				title: "6. License to Use Website & Products",
				content: "<ul style=\"padding-left: 20px;list-style: disc;\"><li>Intellectual property (copyright, trademarks, software, content) belongs to us or our licensors.</li><li>You may view, download, or print for personal use only.</li><li>You must not copy, sell, modify, or distribute any material without permission.</li></ul>"
			},
			acceptableUse: {
				title: "7. Acceptable Use",
				content: "<p>You may not use the Website or Products to:</p><ul style=\"padding-left: 20px;list-style: disc;\"><li>Transmit malware, spam, or illegal content</li><li>Conduct business or employment assessments without permission</li><li>Violate laws, harass, or impersonate others</li><li>Share confidential or copyrighted content unlawfully</li></ul>"
			},
			userContent: {
				title: "8. User Generated Content",
				content: "<ul style=\"padding-left: 20px;list-style: disc;\"><li>You are responsible for any content you post.</li><li>By posting, you grant us a worldwide, royalty-free license to use your content.</li><li>Offensive, illegal, or misleading content is prohibited.</li></ul>"
			},
			noticeTakedown: {
				title: "9. Notice and Takedown",
				content: "<ul style=\"padding-left: 20px;list-style: disc;\"><li>If you believe content infringes your rights, email support{'@'}personalitytest101.com with full details.</li><li>We will investigate and remove infringing content as appropriate.</li></ul>"
			},
			unsolicitedIdeas: {
				title: "10. Unsolicited Idea Submissions",
				content: "<ul style=\"padding-left: 20px;list-style: disc;\"><li>Do not submit ideas or creative works. Any submissions become our sole property without obligation. Feedback can be sent via email excluding ideas.</li></ul>"
			},
			warranties: {
				title: "11. Warranties & Disclaimers",
				content: "<ul style=\"padding-left: 20px;list-style: disc;\"><li>Products are provided \"as is\" without warranties.</li><li>We do not guarantee accuracy, completeness, or availability of Products or AI outputs.</li><li>Our content is informational only and not a substitute for professional advice.</li></ul>"
			},
			liability: {
				title: "12. Liability Limitations",
				content: "<ul style=\"padding-left: 20px;list-style: disc;\"><li>Liability is limited to the extent allowed by law.</li><li>We are not liable for:</li><ul style=\"padding-left: 20px;list-style: disc;\"><li>Business, employment, or recruitment losses</li><li>Emotional or mental distress except due to our negligence</li><li>Loss of data or unforeseeable damages</li></ul><li>AI outputs are used at your own risk.</li></ul>"
			},
			indemnity: {
				title: "13. Indemnity",
				content: "<p>You agree to compensate us for any losses or claims arising from your breach of these terms.</p>"
			},
			breaches: {
				title: "14. Breaches & Enforcement",
				content: "<ul style=\"padding-left: 20px;list-style: disc;\"><li>We may suspend or block access for breaches of these terms.</li><li>Delay in enforcement does not waive our rights.</li></ul>"
			},
			changes: {
				title: "15. Changes & Variation",
				content: "<p>We may revise these terms at any time. Continued use of the website constitutes acceptance.</p>"
			},
			entireAgreement: {
				title: "16. Entire Agreement",
				content: "<p>These terms, together with Privacy Policy and Refund Policy, constitute the complete agreement.</p>"
			},
			contact: {
				title: "17. Contact",
				content: "<p>For support, complaints, or questions: support{'@'}personalitytest101.com</p>"
			}
		}
	}
};
const pages = {
	"404": {
	title: "404: Page Not Found ",
	description: "The page you’re looking for doesn’t exist. Click below to return to the home page and resume your journey.",
	backToHome: "Back to Dashboard"
},
	contact: contact$1,
	about: about$1,
	auth: auth$1,
	faq: faq$3,
	test: test$1,
	orders: orders$1,
	pricing: pricing$1,
	home: home$1,
	testDetail: testDetail,
	personalityDetail: personalityDetail,
	routeGuide: routeGuide$1,
	tests: tests$1,
	testStart: testStart,
	testEnd: testEnd,
	userCourseChapters: userCourseChapters,
	userCourseLearn: userCourseLearn,
	userCourseLesson: userCourseLesson,
	userCourseLessonComplete: userCourseLessonComplete,
	userCourseChapterComplete: userCourseChapterComplete,
	userCourseTest: userCourseTest,
	userCourseTestComplete: userCourseTestComplete,
	ebooks: ebooks$1,
	ebookDetail: ebookDetail,
	profile: profile$1,
	courses: courses$1,
	mentors: mentors$1,
	course: course,
	blog: blog$1,
	account: account$1,
	legal: legal$1
};

var getStarted = "Get Started";
var siteDescription = "Unlock knowledge and growth with expert courses and tools.";
var nav = {
	home: "Home",
	faq: "FAQ",
	signIn: "Sign in",
	takeTheTest: "Take the Test",
	account: "Account"
};
var courseCard = {
	status: {
		completed: "You've completed this test.",
		of: "of",
		lessons: "lessons"
	},
	link: {
		viewResults: "View test results"
	},
	badge: {
		points: "points"
	},
	meta: {
		certificate: "Certificate"
	},
	people: {
		finished: "people already finished it"
	}
};
var api = {
	error: "Error"
};
var faq$2 = {
	title: "Frequently Asked Questions",
	desc: "Find quick answers to common inquiries garding our re assessment process,  report insights, and platform features."
};
var receive = {
	title: "What Makes Our Test Different",
	desc: "Built on validated psychometric frameworks, our assessment transcends surface-level traits. We utilize advanced algorithms to decode the complex psychological drivers that shape your professional and personal identity."
};
var viewResults = "View test results";
var finish = "Finish";
var retakeTest = "Retake test";
var points = "points";
var of = "of";
var lessons = "lessons";
var finished = "finished";
var certificate = "Certificate";
var viewAllBlogs = "View All Blogs";
var step = "STEP";
var stepTotal = "Step {current} of {total}";
var percentIcon = "%";
var price = "$";
var period = ".";
var confirm = "Confirm";
var saveChanges = "Save Changes";
var footer = {
	introduction: "Know yourself. Change everything",
	StayConnected: "Stay connected",
	product: "Product",
	help: "Help",
	legal: "Legal",
	freePersonalityTest: "Free Personality Test",
	contactUs: "Contact Us",
	aboutUs: "About Us",
	faq: "FAQ",
	cancelSubscription: "Cancel Subscription",
	privacyPolicy: "Privacy Policy",
	termsOfUse: "Terms of Use",
	refundPolicy: "Refund Policy",
	payments: "Payments",
	copyright: "2026 © PersonalityTest101. All rights reserved."
};
const common = {
	getStarted: getStarted,
	siteDescription: siteDescription,
	nav: nav,
	courseCard: courseCard,
	api: api,
	faq: faq$2,
	receive: receive,
	viewResults: viewResults,
	finish: finish,
	retakeTest: retakeTest,
	points: points,
	of: of,
	lessons: lessons,
	finished: finished,
	certificate: certificate,
	viewAllBlogs: viewAllBlogs,
	step: step,
	stepTotal: stepTotal,
	percentIcon: percentIcon,
	"continue": "CONTINUE",
	price: price,
	period: period,
	confirm: confirm,
	saveChanges: saveChanges,
	footer: footer
};

var faq$1 = {
	question1: "What is the PersonalityTest101 assessment and how does it work?",
	answer1: "Our personality assessments are designed to help you understand your traits, preferences, and behavioral patterns through a structured set of questions. Once you complete the test, you 'll receive a personalized report with insights into your personality type and practical suggestions for growth.",
	question2: "How do you handle my personal data and privacy?",
	answer2: "We value your privacy and protect your information with secure systems. Your test responses and results are kept confidential and are not shared without your consent. You can review our full Privacy Policy for more details.",
	question3: "How accurate are the personality test results?",
	answer3: "Our tests are designed using trusted psychological frameworks, giving you reliable insights into your personality traits. While no test can capture every detail, the results are meaningful and can help you better understand yourself.",
	question4: "Are there different types of tests available?",
	answer4: "Yes! PersonalityTest101 offers a variety of assessments that explore different aspects of your personality, including traits, strengths, career preferences, and relationship patterns. You can choose the tests that interest you most.",
	question5: "How long will it take to receive my test results?",
	answer5: "You will usually receive your results immediately after completing the test. The exact time the test takes depends on how quickly you answer each question.",
	question6: "How often can I retake the tests?",
	answer6: "You can retake our tests as often as you like. Your results may change over time as your experiences, self-perception, or perspective evolves.",
	question7: "Are the tests scientifically validated?",
	answer7: "Yes, our main assessments are based on widely recognized psychological frameworks and have been tested for reliability and validity, ensuring meaningful results for users.",
	question8: "Are the tests suitable for all age groups?",
	answer8: "Our tests are designed for teens and adults. Some specialized tests may have recommended age ranges — always check the description before starting."
};
var receives = {
	archetypeAnalysis: {
		title: "Comprehensive Archetype Analysis",
		desc: "Uncover your unique archetype with our detailed analysis. Gain insights into your strengths, weaknesses, and unique personality traits."
	},
	careerMapping: {
		title: "Career Alignment Mapping",
		desc: "Discover your ideal career path with our detailed mapping. Understand how your personality aligns with different industries and roles."
	},
	interpersonalGuide: {
		title: "Interpersonal Dynamics Guide",
		desc: "Enhance your relationships with our guide on understanding and managing interpersonal dynamics."
	},
	aiGrowthCoach: {
		title: "Personalized AI Growth Coach",
		desc: "Receive personalized coaching from our AI-powered growth coach. Receive tailored strategies to help you achieve your personal and professional goals."
	},
	selfEsteemBlueprint: {
		title: "Self-Esteem Mastery Blueprint",
		desc: "Master the art of self-esteem with our blueprint. Learn effective techniques to boost your self-confidence and self-esteem."
	},
	personalityReport: {
		title: "Comprehensive Personality Report",
		desc: "Explore data-driven insights into your core traits, behavioral patterns, and hidden potential."
	},
	courseRecommendations: {
		title: "Personalized Course Recommendations",
		desc: "Customized learning paths tailored to your personality archetype to accelerate professional growth."
	},
	skillAssessment: {
		title: "Skill Assessment Tests",
		desc: "Validate your competencies with targeted evaluations aligned to your specific career ambitions."
	},
	dailyChallenges: {
		title: "Practical Daily Challenges",
		desc: "Actionable daily tasks designed to turn psychological insights into lasting personal habits."
	},
	learningLibrary: {
		title: "Learning and Development Library",
		desc: "Explore a comprehensive digital archive designed to fuel your personal growth."
	},
	transparency: {
		title: "Transparency and Value",
		desc: "Clear, measurable insights prioritizing data integrity and delivering exceptional value without complexity."
	}
};
var pricingCards = {
	personalityReport: {
		title: "Comprehensive Personality Report",
		desc: "Get deep insights into your unique personality traits and strengths"
	},
	courseRecommendations: {
		title: "Personalized Course Recommendations",
		desc: "Course recommendations tailored to your goals and interests"
	},
	skillAssessment: {
		title: "Skill Assessment Tests",
		desc: "Test your skills with accurate assessments and feedback"
	},
	dailyChallenges: {
		title: "Practical Daily Challenges",
		desc: "Quick exercises to help you learn something new daily"
	},
	learningLibrary: {
		title: "Learning and Development Library",
		desc: "Explore a digital library designed to support your personal growth journey"
	},
	transparency: {
		title: "Transparency and Value",
		desc: "Clear insights that deliver real value without complexity"
	}
};
const datas = {
	faq: faq$1,
	receives: receives,
	pricingCards: pricingCards
};

var contact = {
	title: "Contact Us {separator} PersonalityTest101 – We’re Here to Help",
	description: "Have questions about our personality tests or need support? Contact the PersonalityTest101 team for assistance, feedback, or collaboration opportunities. We’re happy to hear from you."
};
var test = {
	index: {
		title: "Free Personality Test {separator} PersonalityTest101 – Discover Your True Self",
		description: "Take our free personality test to uncover your unique traits and strengths. Get detailed insights into your personality type and learn how to unlock your full potential in life and career. Start your journey today with PersonalityTest101."
	},
	analyzing: {
		title: "Analysis in Progress {separator} PersonalityTest101 – Decoding Your Unique Traits",
		description: "Meta Description Our system is decoding your responses to generate a precise personality profile. Discover the science behind your behavior and unlock deep insights into your core traits and potential."
	},
	report: {
		title: "Your Personality Report {separator} PersonalityTest101 – Expert Insights",
		description: "Your personality profile is ready. Explore the science behind your traits, unlock deep behavioral insights, and get a tailored roadmap for your personal and professional growth."
	},
	finish: {
		title: "Analysis in Progress {separator} PersonalityTest101 – Decoding Your Traits",
		description: "Our system is decoding your responses to generate a precise personality profile. Discover the science behind your behavior and unlock deep insights into your core potential."
	}
};
var about = {
	title: "About Us {separator} PersonalityTest101 – Our Mission for Self-Discovery",
	description: "Discover the story behind PersonalityTest101. We combine psychological precision with data-driven insights to help individuals uncover their core traits, improve relationships, and achieve personal growth. Learn more about our mission and vision."
};
var orders = {
	cancelSubscription: {
		title: "Cancel Subscription {separator} PersonalityTest101 – Manage Your Account",
		description: "Easily manage or cancel your PersonalityTest101 subscription. We’re sorry to see you go, but you can deactivate your account or change your plan at any time through our secure portal."
	},
	purchaseComplete: {
		title: "Payment Successful {separator} PersonalityTest101 - Start Your Growth Journey",
		description: "Thank you for your purchase! Your premium personality analysis and self-esteem guidebook are ready. Access your insights now on PersonalityTest101."
	},
	create: {
		title: "Secure Checkout {separator} PersonalityTest101 – Start Your 7-Day Trial",
		description: "Unlock unlimited personality reports for just $1.99. Start your 7-day trial today and get professional insights into your strengths and behavioral patterns. Secure payment powered by SSL."
	}
};
var faq = {
	title: "Privacy & Help Center {separator} PersonalityTest101 - Your Data Security",
	description: "Find answers to common questions about PersonalityTest101. Learn how we use your assessment data, our data sharing policies, and how to manage your cookies for a secure experience."
};
var pricing = {
	title: "Affordable Pricing Plans {separator} PersonalityTest101 - Unlock Your Potential",
	description: "Choose the perfect plan for your self-discovery journey. Get premium personality reports, career blueprints, and growth toolkits starting at just $14/mo. Secure and scientifically validated."
};
var legal = {
	privacy: {
		title: "Privacy Policy {separator} PersonalityTest101 - Your Data Security Matters",
		description: "Read our Privacy Policy to understand how PersonalityTest101 collects, protects, and manages your personal data and assessment results. Committed to your privacy and security."
	},
	terms: {
		title: "Personality Test 101 – Terms of Use, Subscription & Refund Policy",
		description: "Read the full Terms of Use and Purchase at Personality Test 101. Learn about subscriptions, digital content usage, AI tools, refunds, cancellations, and your rights as a user. Stay informed and enjoy our personality tests safely."
	},
	refund: {
		title: "Refund & Cancellation Policy {separator} Personality Test 101",
		description: "Learn about our refund and cancellation policy at Personality Test 101. Understand subscription types, refund eligibility, and your right to cancel digital content within 14 days. Personalized reports are delivered instantly, and our friendly support team is here to help."
	}
};
var account = {
	settings: {
		title: "Account Settings {separator} Manage Profile, Security & Language Preferences",
		description: "Manage your account settings, update personal information, change your password, select your preferred language, or delete your account securely."
	}
};
var auth = {
	signIn: {
		title: "Sign In {separator} PersonalityTest101 - Access Your Reports",
		description: "Sign in to PersonalityTest101 to access your professional personality reports, track your growth, and unlock career insights. Secure and easy access."
	}
};
var home = {
	title: "Unlock knowledge and growth with expert courses and tools.",
	description: "An exceptional platform for career development. The current curriculum, skilled instructors, and hands-on learning are truly rewarding."
};
var userCourse = {
	lessonComplete: {
		title: "Analysis in Progress | PersonalityTest101 – Decoding Your Traits",
		description: "Our system is decoding your responses to generate a precise personality profile. Discover the science behind your behavior and unlock deep insights into your core potential."
	}
};
var ebooks = {
	title: "Ebooks - Expert Knowledge and Resources",
	description: "Explore our collection of expert-crafted ebooks on personal development and career growth."
};
var profile = {
	title: "Your Profile - Personal Dashboard",
	description: "Manage your profile and access your test results and learning materials."
};
var tests = {
	title: "Tests - Explore Available Assessments",
	description: "Browse our selection of personality and career assessments."
};
var blog = {
	title: "Blog - Latest Insights and Articles",
	description: "Read our latest articles on personal development, career growth, and industry trends."
};
var courses = {
	title: "Courses - Expert Learning Resources",
	description: "Explore our collection of expert-led courses for personal and professional growth."
};
var mentors = {
	title: "Mentors - Expert Guidance",
	description: "Connect with expert mentors for personalized guidance and support."
};
var routeGuide = {
	title: "Route Guide - Platform Navigation",
	description: "Learn how to navigate our platform and access all features."
};
const seo = {
	"404": {
	title: "Page Not Found {separator} PersonalityTest101 – Let’s Get You Back on Track",
	description: "It looks like this path of self-discovery took an unexpected turn. Whether you’re lost or looking for your Enneagram results, let the PersonalityTest101 team guide you back to your journey of personal growth."
},
	contact: contact,
	test: test,
	about: about,
	orders: orders,
	faq: faq,
	pricing: pricing,
	legal: legal,
	account: account,
	auth: auth,
	home: home,
	userCourse: userCourse,
	"test.start": {
	title: "Start Personality Test - Begin Your Journey",
	description: "Ready to discover your true self? Start the personality test now."
},
	"test.step": {
	title: "Personality Test - Question",
	description: "Answer questions to reveal your personality traits."
},
	"test.analyzing": {
	title: "Analyzing Your Personality - Please Wait",
	description: "We're analyzing your responses to generate your personalized report."
},
	"test.result": {
	title: "Your Personality Results - Insights and Growth",
	description: "View your detailed personality analysis and personalized insights."
},
	ebooks: ebooks,
	"ebooks.detail": {
	title: "Ebook Detail - In-Depth Learning Resource",
	description: "Access detailed information about this expert ebook."
},
	profile: profile,
	"profile.detail": {
	title: "Profile Details - Update Your Information",
	description: "View and update your personal information and preferences."
},
	tests: tests,
	blog: blog,
	"blog.category": {
	title: "Blog Category - Articles by Topic",
	description: "View articles in this blog category."
},
	"blog.slug": {
	title: "Blog Post - Detailed Article",
	description: "Read this in-depth article on personal development."
},
	"orders.cancelSubscription": {
	title: "Cancel Subscription - Manage Membership",
	description: "Cancel your subscription and manage your membership settings."
},
	"orders.purchaseComplete": {
	title: "Purchase Complete - Thank You!",
	description: "Your purchase has been successfully processed."
},
	courses: courses,
	mentors: mentors,
	routeGuide: routeGuide
};

const en = {
  pages,
  common,
  datas,
  seo
};

const en$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: en
}, Symbol.toStringTag, { value: 'Module' }));

const i18n_config = () => ({
  legacy: false,
  locale: "en",
  fallbackLocale: "en",
  warnHtmlMessage: false,
  allowComposition: true,
  lazy: true,
  langDir: "locales",
  defaultLocale: "en",
  locales: [{
    code: "en",
    iso: "en-US",
    file: "en.ts",
    name: "English"
  }, {
    code: "zh",
    iso: "zh-CN",
    file: "zh.ts",
    name: "\u4E2D\u6587"
  }]
});

const i18n_config$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: i18n_config
}, Symbol.toStringTag, { value: 'Module' }));

const template = "";

const _virtual__spaTemplate = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  template: template
}, Symbol.toStringTag, { value: 'Module' }));

const styles = {};

const styles$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: styles
}, Symbol.toStringTag, { value: 'Module' }));

function renderPayloadResponse(ssrContext) {
  return {
    body: stringify(splitPayload(ssrContext).payload, ssrContext._payloadReducers) ,
    statusCode: getResponseStatus(ssrContext.event),
    statusMessage: getResponseStatusText(ssrContext.event),
    headers: {
      "content-type": "application/json;charset=utf-8" ,
      "x-powered-by": "Nuxt"
    }
  };
}
function renderPayloadJsonScript(opts) {
  const contents = opts.data ? stringify(opts.data, opts.ssrContext._payloadReducers) : "";
  const payload = {
    "type": "application/json",
    "innerHTML": contents,
    "data-nuxt-data": appId,
    "data-ssr": !(opts.ssrContext.noSSR)
  };
  {
    payload.id = "__NUXT_DATA__";
  }
  if (opts.src) {
    payload["data-src"] = opts.src;
  }
  const config = uneval(opts.ssrContext.config);
  return [
    payload,
    {
      innerHTML: `window.__NUXT__={};window.__NUXT__.config=${config}`
    }
  ];
}
function splitPayload(ssrContext) {
  const { data, prerenderedAt, ...initial } = ssrContext.payload;
  return {
    initial: { ...initial, prerenderedAt },
    payload: { data, prerenderedAt }
  };
}

const renderSSRHeadOptions = {"omitLineBreaks":true};

globalThis.__buildAssetsURL = buildAssetsURL;
globalThis.__publicAssetsURL = publicAssetsURL;
const HAS_APP_TELEPORTS = !!(appTeleportAttrs.id);
const APP_TELEPORT_OPEN_TAG = HAS_APP_TELEPORTS ? `<${appTeleportTag}${propsToString(appTeleportAttrs)}>` : "";
const APP_TELEPORT_CLOSE_TAG = HAS_APP_TELEPORTS ? `</${appTeleportTag}>` : "";
const PAYLOAD_URL_RE = /^[^?]*\/_payload.json(?:\?.*)?$/ ;
const renderer = defineRenderHandler(async (event) => {
  const nitroApp = useNitroApp();
  const ssrError = event.path.startsWith("/__nuxt_error") ? getQuery$1(event) : null;
  if (ssrError && !("__unenv__" in event.node.req)) {
    throw createError({
      statusCode: 404,
      statusMessage: "Page Not Found: /__nuxt_error"
    });
  }
  const ssrContext = createSSRContext(event);
  const headEntryOptions = { mode: "server" };
  ssrContext.head.push(appHead, headEntryOptions);
  if (ssrError) {
    ssrError.statusCode &&= Number.parseInt(ssrError.statusCode);
    if (typeof ssrError.data === "string") {
      try {
        ssrError.data = destr(ssrError.data);
      } catch {
      }
    }
    setSSRError(ssrContext, ssrError);
  }
  const isRenderingPayload = PAYLOAD_URL_RE.test(ssrContext.url);
  if (isRenderingPayload) {
    const url = ssrContext.url.substring(0, ssrContext.url.lastIndexOf("/")) || "/";
    ssrContext.url = url;
    event._path = event.node.req.url = url;
  }
  const routeOptions = getRouteRules(event);
  if (routeOptions.ssr === false) {
    ssrContext.noSSR = true;
  }
  const renderer = await getRenderer(ssrContext);
  const _rendered = await renderer.renderToString(ssrContext).catch(async (error) => {
    if (ssrContext._renderResponse && error.message === "skipping render") {
      return {};
    }
    const _err = !ssrError && ssrContext.payload?.error || error;
    await ssrContext.nuxt?.hooks.callHook("app:error", _err);
    throw _err;
  });
  const inlinedStyles = [];
  await ssrContext.nuxt?.hooks.callHook("app:rendered", { ssrContext, renderResult: _rendered });
  if (ssrContext._renderResponse) {
    return ssrContext._renderResponse;
  }
  if (ssrContext.payload?.error && !ssrError) {
    throw ssrContext.payload.error;
  }
  if (isRenderingPayload) {
    const response = renderPayloadResponse(ssrContext);
    return response;
  }
  const NO_SCRIPTS = routeOptions.noScripts;
  const { styles, scripts } = getRequestDependencies(ssrContext, renderer.rendererContext);
  if (ssrContext._preloadManifest && !NO_SCRIPTS) {
    ssrContext.head.push({
      link: [
        { rel: "preload", as: "fetch", fetchpriority: "low", crossorigin: "anonymous", href: buildAssetsURL(`builds/meta/${ssrContext.runtimeConfig.app.buildId}.json`) }
      ]
    }, { ...headEntryOptions, tagPriority: "low" });
  }
  if (inlinedStyles.length) {
    ssrContext.head.push({ style: inlinedStyles });
  }
  const link = [];
  for (const resource of Object.values(styles)) {
    if ("inline" in getQuery(resource.file)) {
      continue;
    }
    link.push({ rel: "stylesheet", href: renderer.rendererContext.buildAssetsURL(resource.file), crossorigin: "" });
  }
  if (link.length) {
    ssrContext.head.push({ link }, headEntryOptions);
  }
  if (!NO_SCRIPTS) {
    ssrContext.head.push({
      link: getPreloadLinks(ssrContext, renderer.rendererContext)
    }, headEntryOptions);
    ssrContext.head.push({
      link: getPrefetchLinks(ssrContext, renderer.rendererContext)
    }, headEntryOptions);
    ssrContext.head.push({
      script: renderPayloadJsonScript({ ssrContext, data: ssrContext.payload }) 
    }, {
      ...headEntryOptions,
      // this should come before another end of body scripts
      tagPosition: "bodyClose",
      tagPriority: "high"
    });
  }
  if (!routeOptions.noScripts) {
    const tagPosition = "head";
    ssrContext.head.push({
      script: Object.values(scripts).map((resource) => ({
        type: resource.module ? "module" : null,
        src: renderer.rendererContext.buildAssetsURL(resource.file),
        defer: resource.module ? null : true,
        // if we are rendering script tag payloads that import an async payload
        // we need to ensure this resolves before executing the Nuxt entry
        tagPosition,
        crossorigin: ""
      }))
    }, headEntryOptions);
  }
  const { headTags, bodyTags, bodyTagsOpen, htmlAttrs, bodyAttrs } = await renderSSRHead(ssrContext.head, renderSSRHeadOptions);
  const htmlContext = {
    htmlAttrs: htmlAttrs ? [htmlAttrs] : [],
    head: normalizeChunks([headTags]),
    bodyAttrs: bodyAttrs ? [bodyAttrs] : [],
    bodyPrepend: normalizeChunks([bodyTagsOpen, ssrContext.teleports?.body]),
    body: [
      replaceIslandTeleports(ssrContext, _rendered.html) ,
      APP_TELEPORT_OPEN_TAG + (HAS_APP_TELEPORTS ? joinTags([ssrContext.teleports?.[`#${appTeleportAttrs.id}`]]) : "") + APP_TELEPORT_CLOSE_TAG
    ],
    bodyAppend: [bodyTags]
  };
  await nitroApp.hooks.callHook("render:html", htmlContext, { event });
  return {
    body: renderHTMLDocument(htmlContext),
    statusCode: getResponseStatus(event),
    statusMessage: getResponseStatusText(event),
    headers: {
      "content-type": "text/html;charset=utf-8",
      "x-powered-by": "Nuxt"
    }
  };
});
function normalizeChunks(chunks) {
  const result = [];
  for (const _chunk of chunks) {
    const chunk = _chunk?.trim();
    if (chunk) {
      result.push(chunk);
    }
  }
  return result;
}
function joinTags(tags) {
  return tags.join("");
}
function joinAttrs(chunks) {
  if (chunks.length === 0) {
    return "";
  }
  return " " + chunks.join(" ");
}
function renderHTMLDocument(html) {
  return `<!DOCTYPE html><html${joinAttrs(html.htmlAttrs)}><head>${joinTags(html.head)}</head><body${joinAttrs(html.bodyAttrs)}>${joinTags(html.bodyPrepend)}${joinTags(html.body)}${joinTags(html.bodyAppend)}</body></html>`;
}

const renderer$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: renderer
}, Symbol.toStringTag, { value: 'Module' }));
//# sourceMappingURL=index.mjs.map
