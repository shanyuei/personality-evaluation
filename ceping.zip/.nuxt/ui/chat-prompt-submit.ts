export default {
  "slots": {
    "base": ""
  }
}