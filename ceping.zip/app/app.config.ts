export default defineAppConfig({
  ui: {
  
  }
})
