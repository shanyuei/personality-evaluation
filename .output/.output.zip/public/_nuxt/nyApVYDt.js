import{a2 as l,Z as s}from"./DYacvIsm.js";function t(r,i){return l(r)?!1:Array.isArray(r)?r.some(a=>s(a,i)):s(r,i)}export{t as i};
