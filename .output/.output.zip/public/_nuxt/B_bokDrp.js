import{c as e,a$ as r,a9 as t}from"./DYacvIsm.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
