import{a6 as l,a2 as s}from"./Ch2dYCmK.js";function t(r,i){return l(r)?!1:Array.isArray(r)?r.some(a=>s(a,i)):s(r,i)}export{t as i};
