import{c as e,aP as r,ad as t}from"./Ch2dYCmK.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
